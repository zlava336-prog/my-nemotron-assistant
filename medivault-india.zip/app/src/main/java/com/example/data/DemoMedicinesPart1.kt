package com.example.data

import com.example.model.*

object DemoMedicinesPart1 {
    val list = listOf(
        // 1. Paracetamol
        MedicineRecord(
            id = "med-001",
            genericName = "Paracetamol",
            saltName = "Acetaminophen",
            activeIngredients = listOf("Paracetamol"),
            brandNames = listOf(
                BrandInfo("Dolo 650", "Paracetamol", listOf("Paracetamol"), "650 mg", "Tablet", "Micro Labs Ltd", false, "Rs. 30 / 15 tabs"),
                BrandInfo("Calpol 500", "Paracetamol", listOf("Paracetamol"), "500 mg", "Tablet", "GSK India", false, "Rs. 18 / 15 tabs"),
                BrandInfo("Crocin 650", "Paracetamol", listOf("Paracetamol"), "650 mg", "Tablet", "GSK Consumer", false, "Rs. 32 / 15 tabs")
            ),
            strength = "500 mg / 650 mg",
            dosageForms = listOf("Tablet", "Syrup", "Injection", "Suppository"),
            routes = listOf("Oral", "Intravenous", "Rectal"),
            pronunciation = "pah-rah-SEE-tah-mol",
            romanPronunciation = "Para-set-a-mol",
            hinglishPronunciation = "Bukhar aur dard ki aam dawai (Paracetamol)",
            therapeuticClass = "Analgesic & Antipyretic",
            pharmacologicalClass = "Aniline Derivative / COX Inhibitor (Central)",
            drugClass = "Non-Opioid Analgesic",
            atcCode = "N02BE01",
            mechanismOfAction = "Inhibits cyclooxygenase (COX-1 and COX-2) enzymes centrally in the CNS, reducing prostaglandin synthesis in the hypothalamus to lower fever and raise pain threshold.",
            indications = listOf("Pyrexia (Fever)", "Mild to Moderate Pain", "Headache", "Myalgia", "Post-vaccination pyrexia"),
            uses = listOf("Reducing body temperature during fever", "Relieving mild headache and body aches", "Managing fever in pediatric patients"),
            contraindications = listOf("Severe hepatic impairment", "Known hypersensitivity to paracetamol"),
            warnings = listOf("Do not exceed 4000 mg/day in adults to avoid acute liver failure.", "Caution in chronic alcoholics and malnourished patients."),
            precautions = listOf("Check combination cough/cold medications to prevent double dosing of paracetamol."),
            adverseEffects = listOf("Nausea", "Rash", "Hepatotoxicity (in overdose)", "Thrombocytopenia (rare)"),
            commonSideEffects = listOf("Mild nausea", "Allergic skin rash (uncommon)"),
            seriousSideEffects = listOf("Acute hepatic necrosis", "Stevens-Johnson syndrome (very rare)"),
            drugInteractions = listOf(
                StructuredInteraction("Warfarin", "Moderate", "Increased INR and risk of bleeding with prolonged high-dose paracetamol.", "Enhances anticoagulant effect.", "Monitor INR closely."),
                StructuredInteraction("Alcohol", "Major", "Increased risk of severe liver damage.", "Synergistic hepatotoxicity.", "Avoid chronic alcohol ingestion with paracetamol.")
            ),
            foodInteractions = listOf("High-carbohydrate meals may slightly delay oral absorption."),
            adme = ADMEInfo(
                absorption = "Rapid and almost complete from gastrointestinal tract. Peak plasma concentration in 30-60 mins.",
                distribution = "Distributed uniformly into most body tissues. Plasma protein binding is low (10-25%).",
                metabolism = "Hepatic metabolism via glucuronidation (60%) and sulfation (35%). Minor CYP2E1 pathway generates toxic NAPQI.",
                excretion = "Renal excretion of conjugated metabolites. Less than 5% excreted unchanged in urine.",
                bioavailability = "70% to 90%",
                proteinBinding = "10% to 25%",
                volumeOfDistribution = "0.95 L/kg",
                metabolicPathway = "Hepatic Glucuronidation & Sulfation",
                majorEnzymes = listOf("CYP2E1", "UGT1A1"),
                halfLife = "2 to 3 hours",
                routeOfElimination = "Renal (Urinary)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Considered safe at therapeutic doses during pregnancy under supervision.",
                lactation = "Excreted in breast milk in small amounts; compatible with breastfeeding.",
                pediatric = "Weight-based dosing (10-15 mg/kg per dose every 4-6 hours).",
                geriatric = "Standard doses usually tolerated; reduce in chronic hepatic insufficiency."
            ),
            monitoring = listOf("Liver function tests in prolonged high-dose use", "Daily cumulative dose calculation"),
            patientCounselling = listOf("Do not take other paracetamol-containing products simultaneously.", "Avoid alcohol while taking this medicine."),
            advantages = listOf("Safe for gastric mucosa (unlike NSAIDs)", "Safe for patients with aspirin triad or bleeding risk"),
            limitations = listOf("Lacks anti-inflammatory action at standard therapeutic doses", "Risk of liver toxicity in overdose"),
            memoryTrick = "Para-cet-amol = Pain & Pyrexia (fever) Away Central Action.",
            references = listOf("Indian Pharmacopoeia (IP)", "Central Drugs Standard Control Organization (CDSCO)"),
            sourceUrls = listOf("https://cdsco.gov.in")
        ),

        // 2. Ibuprofen
        MedicineRecord(
            id = "med-002",
            genericName = "Ibuprofen",
            saltName = "Ibuprofen Sodium / Acid",
            activeIngredients = listOf("Ibuprofen"),
            brandNames = listOf(
                BrandInfo("Brufen 400", "Ibuprofen", listOf("Ibuprofen"), "400 mg", "Tablet", "Abbott India", false, "Rs. 15 / 15 tabs"),
                BrandInfo("Combiflam", "Ibuprofen + Paracetamol", listOf("Ibuprofen", "Paracetamol"), "400 mg + 325 mg", "Tablet", "Sanofi India", true, "Rs. 25 / 15 tabs")
            ),
            strength = "200 mg / 400 mg",
            dosageForms = listOf("Tablet", "Syrup", "Gel"),
            routes = listOf("Oral", "Topical"),
            pronunciation = "eye-byoo-PRO-fen",
            romanPronunciation = "Eye-byoo-pro-fen",
            hinglishPronunciation = "Dard aur sujan ki dawai (Ibuprofen)",
            therapeuticClass = "NSAID (Non-Steroidal Anti-Inflammatory Drug)",
            pharmacologicalClass = "Propionic Acid Derivative",
            drugClass = "Non-Selective COX Inhibitor",
            atcCode = "M01AE01",
            mechanismOfAction = "Reversibly inhibits COX-1 and COX-2 enzymes, decreasing peripheral prostaglandin synthesis to relieve inflammation, pain, and fever.",
            indications = listOf("Rheumatoid Arthritis", "Osteoarthritis", "Dysmenorrhea", "Post-operative Pain", "Fever"),
            uses = listOf("Relieving inflammatory joint pain", "Managing menstrual cramps", "Reducing swelling and fever"),
            contraindications = listOf("Active peptic ulcer disease", "Severe heart failure", "Third trimester of pregnancy", "CABG surgery perioperative pain"),
            warnings = listOf("Increased risk of gastrointestinal bleeding and ulceration.", "May increase risk of cardiovascular thrombotic events."),
            precautions = listOf("Take with food or milk to minimize gastric distress.", "Use lowest effective dose for shortest duration."),
            adverseEffects = listOf("Epigastric distress", "Heartburn", "GI bleeding", "Fluid retention", "Renal impairment"),
            commonSideEffects = listOf("Dyspepsia", "Nausea", "Abdominal discomfort"),
            seriousSideEffects = listOf("Gastrointestinal ulceration/perforation", "Acute renal failure", "Myocardial infarction risk"),
            drugInteractions = listOf(
                StructuredInteraction("Aspirin", "Major", "Ibuprofen may attenuate the irreversible antiplatelet effect of low-dose aspirin.", "Competitive COX-1 binding.", "Take aspirin 30 mins before or 8 hours after ibuprofen."),
                StructuredInteraction("Amlodipine", "Moderate", "NSAIDs reduce antihypertensive efficiency.", "Inhibition of renal vasodilatory prostaglandins.", "Monitor blood pressure.")
            ),
            foodInteractions = listOf("Take immediately after food to reduce stomach irritation."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed from stomach and intestines. Peak level in 1-2 hours.",
                distribution = "Highly bound to plasma proteins (99%). Penetrates synovial fluid.",
                metabolism = "Extensive hepatic metabolism via CYP2C9 to inactive metabolites.",
                excretion = "Renal excretion (90% as metabolites and conjugates).",
                bioavailability = "80%",
                proteinBinding = "99%",
                volumeOfDistribution = "0.12 L/kg",
                metabolicPathway = "Hepatic CYP2C9 Hydroxylation",
                majorEnzymes = listOf("CYP2C9", "CYP2C8"),
                halfLife = "2 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Contraindicated in 3rd trimester (premature closure of ductus arteriosus).",
                lactation = "Excreted in low levels; compatible with breastfeeding for short courses."
            ),
            monitoring = listOf("Serum creatinine and BUN in prolonged use", "Hemoglobin for occult GI bleeding"),
            patientCounselling = listOf("Do not take on an empty stomach.", "Report black tarry stools immediately."),
            advantages = listOf("Effective anti-inflammatory component", "Rapid onset of pain relief"),
            limitations = listOf("Gastric toxicity risk", "Renal vasoconstriction in dehydration"),
            memoryTrick = "IbuPROfen = PROpionic acid NSAID for Pain & Swelling.",
            references = listOf("CDSCO Approved Drug List", "British National Formulary (BNF)")
        ),

        // 3. Diclofenac
        MedicineRecord(
            id = "med-003",
            genericName = "Diclofenac",
            saltName = "Diclofenac Sodium / Potassium",
            activeIngredients = listOf("Diclofenac"),
            brandNames = listOf(
                BrandInfo("Voveran 50", "Diclofenac Sodium", listOf("Diclofenac"), "50 mg", "Tablet", "Novartis India", false, "Rs. 20 / 10 tabs"),
                BrandInfo("Voveran SR 100", "Diclofenac Sodium", listOf("Diclofenac"), "100 mg", "SR Tablet", "Novartis India", false, "Rs. 45 / 10 tabs"),
                BrandInfo("Omnigel", "Diclofenac Topical", listOf("Diclofenac"), "1.16%", "Gel", "Cipla", false, "Rs. 85 / 30g tube")
            ),
            strength = "50 mg / 75 mg / 100 mg",
            dosageForms = listOf("Tablet", "SR Tablet", "Injection", "Gel", "Suppository"),
            routes = listOf("Oral", "Intramuscular", "Topical"),
            pronunciation = "dye-KLOE-fen-ak",
            romanPronunciation = "Dye-klo-fen-ak",
            hinglishPronunciation = "Tez dard aur jod ke dard ki dawai (Diclofenac)",
            therapeuticClass = "NSAID",
            pharmacologicalClass = "Phenylacetic Acid Derivative",
            drugClass = "Non-Selective COX Inhibitor",
            atcCode = "M01AB05",
            mechanismOfAction = "Inhibits COX-1 and COX-2 enzymes with moderate COX-2 selectivity. Also reduces intracellular arachidonic acid concentration.",
            indications = listOf("Rheumatoid Arthritis", "Ankylosing Spondylitis", "Acute Gout", "Post-operative Pain", "Renal Colic"),
            uses = listOf("Relieving severe joint pain", "Managing acute post-surgical inflammation", "Topical application for sprains and strains"),
            contraindications = listOf("Congestive heart failure (NYHA II-IV)", "Ischemic heart disease", "Active peptic ulcer"),
            warnings = listOf("Higher cardiovascular risk compared to other non-selective NSAIDs.", "Risk of severe hepatic injury."),
            precautions = listOf("Monitor liver function tests in patients receiving long-term therapy."),
            adverseEffects = listOf("Epigastric pain", "Elevated ALT/AST", "Fluid retention", "GI ulceration"),
            commonSideEffects = listOf("Gastric irritation", "Nausea", "Headache"),
            seriousSideEffects = listOf("Hepatotoxicity", "Myocardial infarction", "GI bleeding"),
            drugInteractions = listOf(
                StructuredInteraction("Methotrexate", "Major", "Diclofenac decreases renal clearance of methotrexate, increasing toxicity.", "Inhibition of tubular secretion.", "Avoid combination or monitor serum methotrexate.")
            ),
            foodInteractions = listOf("Food delays absorption rate but does not affect total absorption."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed. Significant first-pass metabolism (~50% reaches systemic circulation).",
                distribution = "Extensively bound to plasma albumin (>99%). High concentration in synovial fluid.",
                metabolism = "Hepatic metabolism via CYP2C9 to 4'-hydroxydiclofenac.",
                excretion = "65% excreted in urine, 35% in bile as glucuronide and sulfate conjugates.",
                bioavailability = "50%",
                proteinBinding = "99.7%",
                volumeOfDistribution = "0.12 L/kg",
                metabolicPathway = "CYP2C9 Hydroxylation",
                majorEnzymes = listOf("CYP2C9"),
                halfLife = "1.2 to 2 hours",
                routeOfElimination = "Urinary & Biliary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Avoid in late pregnancy due to risk of arterial duct closure.",
                geriatric = "Use lowest dose; higher risk of GI and cardiovascular side effects."
            ),
            monitoring = listOf("Liver function tests (LFT) within 4-8 weeks of starting", "Blood pressure"),
            patientCounselling = listOf("Take with meal.", "Do not crush or chew SR tablets."),
            advantages = listOf("Potent anti-inflammatory efficacy", "Multiple formulations (gel, injection, tablet)"),
            limitations = listOf("Higher cardiovascular and hepatic risk profile"),
            memoryTrick = "Diclo-FENAC = Phenylacetic acid NSAID for severe Inflammatory pain.",
            references = listOf("Indian Pharmacopoeia (IP)", "CDSCO")
        ),

        // 4. Aceclofenac
        MedicineRecord(
            id = "med-004",
            genericName = "Aceclofenac",
            saltName = "Aceclofenac",
            activeIngredients = listOf("Aceclofenac"),
            brandNames = listOf(
                BrandInfo("Atratect 100", "Aceclofenac", listOf("Aceclofenac"), "100 mg", "Tablet", "Sun Pharma", false, "Rs. 35 / 10 tabs"),
                BrandInfo("Zerodol SP", "Aceclofenac + Paracetamol + Serratiopeptidase", listOf("Aceclofenac", "Paracetamol", "Serratiopeptidase"), "100 mg + 325 mg + 15 mg", "Tablet", "Ipca Laboratories", true, "Rs. 110 / 10 tabs")
            ),
            strength = "100 mg",
            dosageForms = listOf("Tablet", "SR Tablet"),
            routes = listOf("Oral"),
            pronunciation = "a-SEE-kloe-fen-ak",
            romanPronunciation = "A-see-klo-fen-ak",
            hinglishPronunciation = "Jod ke dard ki dawai (Aceclofenac)",
            therapeuticClass = "NSAID",
            pharmacologicalClass = "Phenylacetic Acid Derivative (Prodrug of Diclofenac)",
            drugClass = "COX-2 Preferential Inhibitor",
            atcCode = "M01AB16",
            mechanismOfAction = "Inhibits COX enzyme and cytokine production (IL-1beta, TNF-alpha). Biotransformed in part to diclofenac, providing anti-inflammatory relief with better gastric tolerance.",
            indications = listOf("Osteoarthritis", "Rheumatoid Arthritis", "Ankylosing Spondylitis", "Dental Pain"),
            uses = listOf("Relieving joint stiffness and swelling in arthritis", "Managing post-dental pain"),
            contraindications = listOf("Active GI bleeding", "Severe renal/hepatic impairment", "Heart failure"),
            warnings = listOf("Use with gastroprotective agents in patients with ulcer history."),
            precautions = listOf("Monitor renal function in elderly patients."),
            adverseEffects = listOf("Dyspepsia", "Abdominal pain", "Dizziness", "Rash"),
            commonSideEffects = listOf("Mild gastric irritation", "Nausea"),
            seriousSideEffects = listOf("GI ulceration", "Renal impairment"),
            drugInteractions = listOf(
                StructuredInteraction("Anticoagulants", "Major", "Increased risk of bleeding.", "Additive antiplatelet effect.", "Monitor coagulation parameters.")
            ),
            foodInteractions = listOf("Take after food to reduce stomach disturbance."),
            adme = ADMEInfo(
                absorption = "Rapidly and completely absorbed. Peak levels in 1.25 - 3 hours.",
                distribution = "Protein binding > 99%. Good penetration into synovial fluid.",
                metabolism = "Hepatic metabolism to 4'-hydroxyaceclofenac and diclofenac.",
                excretion = "Renal excretion (~70-80%).",
                bioavailability = "High (~100%)",
                proteinBinding = "> 99%",
                volumeOfDistribution = "0.2 L/kg",
                metabolicPathway = "Hepatic Hydroxylation",
                majorEnzymes = listOf("CYP2C9"),
                halfLife = "4 hours",
                routeOfElimination = "Renal"
            ),
            specialPopulations = SpecialPopulations(pregnancy = "Avoid during 3rd trimester."),
            monitoring = listOf("Serum creatinine in prolonged use"),
            patientCounselling = listOf("Take after meals with plenty of water."),
            advantages = listOf("Better gastric tolerance than diclofenac", "Popular combination options with serratiopeptidase"),
            limitations = listOf("Not available in all global markets; widely used in India"),
            memoryTrick = "Ace-clo-fenac = Ace tolerance NSAID for Arthritis.",
            references = listOf("CDSCO Approved List", "Indian Pharmacopoeia")
        ),

        // 5. Amoxicillin
        MedicineRecord(
            id = "med-005",
            genericName = "Amoxicillin",
            saltName = "Amoxicillin Trihydrate",
            activeIngredients = listOf("Amoxicillin"),
            brandNames = listOf(
                BrandInfo("Mox 500", "Amoxicillin", listOf("Amoxicillin"), "500 mg", "Capsule", "Sun Pharma", false, "Rs. 65 / 15 caps"),
                BrandInfo("Augmentin 625 DUO", "Amoxicillin + Clavulanic Acid", listOf("Amoxicillin", "Clavulanate Potassium"), "500 mg + 125 mg", "Tablet", "GSK India", true, "Rs. 200 / 10 tabs"),
                BrandInfo("Moxikind-CV 625", "Amoxicillin + Clavulanic Acid", listOf("Amoxicillin", "Clavulanic Acid"), "500 mg + 125 mg", "Tablet", "Mankind Pharma", true, "Rs. 170 / 10 tabs")
            ),
            strength = "250 mg / 500 mg",
            dosageForms = listOf("Capsule", "Tablet", "Dry Syrup", "Injection"),
            routes = listOf("Oral", "Intravenous"),
            pronunciation = "ah-moks-i-SIL-in",
            romanPronunciation = "Amox-i-sil-in",
            hinglishPronunciation = "Bacteria infection ki dawai (Amoxicillin antibiotic)",
            therapeuticClass = "Antibacterial / Antibiotic",
            pharmacologicalClass = "Aminopenicillin",
            drugClass = "Beta-Lactam Antibiotic",
            atcCode = "J01CA04",
            mechanismOfAction = "Binds to Penicillin-Binding Proteins (PBPs) on bacterial cell walls, inhibiting peptidoglycan synthesis and causing bacterial cell lysis and death.",
            indications = listOf("Respiratory Tract Infections", "Otitis Media", "Sinusitis", "Urinary Tract Infections", "H. pylori Eradication"),
            uses = listOf("Treating bacterial throat and chest infections", "Managing bacterial ear and sinus infections"),
            contraindications = listOf("History of severe allergic reaction (anaphylaxis) to penicillins or beta-lactams"),
            warnings = listOf("Risk of severe hypersensitivity reactions.", "Clostridium difficile-associated diarrhea (CDAD) risk."),
            precautions = listOf("Complete full prescribed course to prevent antibiotic resistance.", "Adjust dose in severe renal impairment."),
            adverseEffects = listOf("Diarrhea", "Nausea", "Skin rash", "Urticaria", "Candidiasis"),
            commonSideEffects = listOf("Mild diarrhea", "Nausea", "Vomiting"),
            seriousSideEffects = listOf("Anaphylactic shock", "Stevens-Johnson syndrome", "Pseudomembranous colitis"),
            drugInteractions = listOf(
                StructuredInteraction("Allopurinol", "Moderate", "Increased incidence of skin rashes when taken together.", "Unclear mechanism.", "Monitor for rash."),
                StructuredInteraction("Methotrexate", "Major", "Reduced renal clearance of methotrexate.", "Competitive renal excretion.", "Monitor methotrexate levels.")
            ),
            foodInteractions = listOf("Can be taken with or without food. Food does not impair absorption."),
            adme = ADMEInfo(
                absorption = "Stable in gastric acid. Rapidly absorbed with peak levels in 1-2 hours.",
                distribution = "Widely distributed into body fluids, bone, and sputum. Low CSF penetration unless meninges inflamed.",
                metabolism = "Partially metabolized (~10-25%) to penicilloic acid.",
                excretion = "Renal tubular secretion and glomerular filtration. 60-70% excreted unchanged in urine within 6 hours.",
                bioavailability = "95%",
                proteinBinding = "20%",
                volumeOfDistribution = "0.3 L/kg",
                metabolicPathway = "Minor Hepatic Hydrolysis",
                majorEnzymes = emptyList(),
                halfLife = "1 to 1.5 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Widely used and safe during pregnancy.",
                lactation = "Excreted in low levels in breast milk; monitor infant for diarrhea or candidiasis.",
                pediatric = "Standard first-line antibiotic in pediatric otitis media."
            ),
            monitoring = listOf("Signs of allergic reaction during initial doses", "Renal function in prolonged high-dose therapy"),
            patientCounselling = listOf("Finish the entire prescribed duration even if feeling better.", "Report severe diarrhea or hives immediately."),
            advantages = listOf("High oral bioavailability compared to ampicillin", "Broad gram-positive and select gram-negative coverage"),
            limitations = listOf("Inactivated by beta-lactamase producing bacteria (unless combined with clavulanate)"),
            memoryTrick = "A-MOX-icillin = AMINO penicillin for BACTERIAL cell wall destruction.",
            references = listOf("National Treatment Guidelines for Antimicrobial Use in Infectious Diseases (India)", "CDSCO")
        ),

        // 6. Azithromycin
        MedicineRecord(
            id = "med-006",
            genericName = "Azithromycin",
            saltName = "Azithromycin Dihydrate",
            activeIngredients = listOf("Azithromycin"),
            brandNames = listOf(
                BrandInfo("Azee 500", "Azithromycin", listOf("Azithromycin"), "500 mg", "Tablet", "Cipla", false, "Rs. 120 / 5 tabs"),
                BrandInfo("Azithral 500", "Azithromycin", listOf("Azithromycin"), "500 mg", "Tablet", "Alembic Pharma", false, "Rs. 115 / 5 tabs")
            ),
            strength = "250 mg / 500 mg",
            dosageForms = listOf("Tablet", "Suspension", "Injection"),
            routes = listOf("Oral", "Intravenous"),
            pronunciation = "ay-zith-roe-MYE-sin",
            romanPronunciation = "A-zith-ro-my-sin",
            hinglishPronunciation = "Gale aur sans ki infection ki antibiotic (Azithromycin)",
            therapeuticClass = "Antibacterial",
            pharmacologicalClass = "Azalide (Subclass of Macrolides)",
            drugClass = "Macrolide Antibiotic",
            atcCode = "J01FA10",
            mechanismOfAction = "Binds reversibly to the 50S ribosomal subunit of susceptible bacteria, inhibiting translocation step of protein synthesis.",
            indications = listOf("Upper and Lower Respiratory Tract Infections", "Typhoid Fever", "Chlamydia Infection", "Skin Infections"),
            uses = listOf("Treating bacterial sore throat and bronchitis", "Short 3 to 5 day antibiotic courses"),
            contraindications = listOf("History of cholestatic jaundice or hepatic dysfunction associated with prior azithromycin use"),
            warnings = listOf("Risk of QT interval prolongation and torsades de pointes.", "Caution in patients with cardiac arrhythmia."),
            precautions = listOf("Do not take antacids containing aluminum or magnesium at the same time."),
            adverseEffects = listOf("Diarrhea", "Abdominal cramping", "Nausea", "QT prolongation", "Hearing impairment (high dose)"),
            commonSideEffects = listOf("Loose stools", "Abdominal discomfort", "Nausea"),
            seriousSideEffects = listOf("Torsades de pointes", "Hepatic failure", "Anaphylaxis"),
            drugInteractions = listOf(
                StructuredInteraction("Antacids (Al/Mg)", "Moderate", "Decreases peak serum concentration of azithromycin.", "Decreased absorption rate.", "Separate administration by 2 hours."),
                StructuredInteraction("Amiodarone", "Major", "Additive prolongation of QT interval.", "Electrophysiological synergism.", "Avoid combination or closely monitor ECG.")
            ),
            foodInteractions = listOf("Suspension can be taken with or without food. Tablets can be taken without regard to meals."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed. Peak serum levels in 2.1 to 3.2 hours.",
                distribution = "Extensive tissue distribution with high intracellular concentration in phagocytes and macrophages.",
                metabolism = "Hepatic metabolism (minor). Mostly excreted unchanged.",
                excretion = "Biliary excretion is the primary route (~50% unchanged drug). Renal excretion is minor (~6%).",
                bioavailability = "37%",
                proteinBinding = "7% to 50% (concentration dependent)",
                volumeOfDistribution = "31.1 L/kg (very high tissue distribution)",
                metabolicPathway = "Minor Hepatic Demethylation",
                majorEnzymes = listOf("CYP3A4"),
                halfLife = "68 to 72 hours (tissue half-life)",
                routeOfElimination = "Biliary (Fecal) & Renal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Used when clinically indicated.",
                pediatric = "Used widely in pediatric respiratory infections in syrup form."
            ),
            monitoring = listOf("ECG in patients with cardiac risk factors", "Liver enzymes in jaundice symptoms"),
            patientCounselling = listOf("Take once daily for the exact duration prescribed.", "Do not take antacids within 2 hours of this medicine."),
            advantages = listOf("Long tissue half-life allows short 3-day treatment courses", "Convenient once-daily dosing"),
            limitations = listOf("Risk of QT prolongation", "Rapid development of resistance if overused"),
            memoryTrick = "A-ZITHRO-mycin = AZALIDE macrolide with LONG half-life (3-5 day dose).",
            references = listOf("CDSCO Approved Drug List", "WHO Essential Medicines List")
        ),

        // 7. Ciprofloxacin
        MedicineRecord(
            id = "med-007",
            genericName = "Ciprofloxacin",
            saltName = "Ciprofloxacin Hydrochloride",
            activeIngredients = listOf("Ciprofloxacin"),
            brandNames = listOf(
                BrandInfo("Ciplox 500", "Ciprofloxacin", listOf("Ciprofloxacin"), "500 mg", "Tablet", "Cipla", false, "Rs. 45 / 10 tabs"),
                BrandInfo("Cifran 500", "Ciprofloxacin", listOf("Ciprofloxacin"), "500 mg", "Tablet", "Sun Pharma", false, "Rs. 42 / 10 tabs")
            ),
            strength = "250 mg / 500 mg",
            dosageForms = listOf("Tablet", "Eye Drops", "Ear Drops", "Injection"),
            routes = listOf("Oral", "Ophthalmic", "Otic", "Intravenous"),
            pronunciation = "sip-roe-FLOKS-ah-sin",
            romanPronunciation = "Sip-ro-flox-a-sin",
            hinglishPronunciation = "Pate aur peshab ki infection ki antibiotic (Ciprofloxacin)",
            therapeuticClass = "Antibacterial",
            pharmacologicalClass = "Second-Generation Fluoroquinolone",
            drugClass = "Fluoroquinolone Antibiotic",
            atcCode = "J01MA02",
            mechanismOfAction = "Inhibits bacterial DNA gyrase (topoisomerase II) and topoisomerase IV, preventing DNA supercoiling and replication, leading to rapid cell death.",
            indications = listOf("Urinary Tract Infections", "Gastroenteritis / Infectious Diarrhea", "Typhoid Fever", "Bone and Joint Infections"),
            uses = listOf("Treating complicated urinary tract infections", "Managing severe bacterial diarrhea"),
            contraindications = listOf("Concomitant tizanidine administration", "History of tendonitis or tendon rupture associated with quinolones"),
            warnings = listOf("Black Box Warning: Tendonitis, tendon rupture, peripheral neuropathy, and CNS effects.", "Avoid in Myasthenia Gravis."),
            precautions = listOf("Maintain adequate hydration to prevent crystalluria.", "Avoid exposure to excess sun (photosensitivity)."),
            adverseEffects = listOf("Nausea", "Diarrhea", "Tendinitis", "Photosensitivity", "Dizziness", "Insomnia"),
            commonSideEffects = listOf("Nausea", "Mild diarrhea", "Headache"),
            seriousSideEffects = listOf("Achilles tendon rupture", "Aortic aneurysm rupture", "QT prolongation", "Clostridium difficile diarrhea"),
            drugInteractions = listOf(
                StructuredInteraction("Dairy / Calcium", "Major", "Chelation with polyvalent cations decreases ciprofloxacin absorption significantly.", "Insoluble complex formation.", "Administer ciprofloxacin 2 hours before or 6 hours after dairy/antacids."),
                StructuredInteraction("Theophylline", "Major", "Ciprofloxacin inhibits theophylline clearance, causing toxicity.", "CYP1A2 inhibition.", "Avoid combination or reduce theophylline dose.")
            ),
            foodInteractions = listOf("Avoid co-administration with calcium-rich foods or milk products alone."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed from GI tract. Bioavailability ~70-80%. Peak in 1-2 hours.",
                distribution = "Widely distributed into tissues, bile, lungs, and urinary organs. Moderate CSF penetration.",
                metabolism = "Hepatic metabolism to 4 metabolites with weak antimicrobial activity.",
                excretion = "Renal excretion (40-50% unchanged in urine) and biliary/fecal excretion.",
                bioavailability = "70% to 80%",
                proteinBinding = "20% to 40%",
                volumeOfDistribution = "2.1 to 2.7 L/kg",
                metabolicPathway = "Hepatic CYP1A2 Inhibition",
                majorEnzymes = listOf("CYP1A2"),
                halfLife = "4 hours",
                routeOfElimination = "Renal & Biliary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Generally avoided due to cartilage toxicity in animal studies.",
                pediatric = "Restricted due to potential arthropathy; used only in specific conditions (e.g. CF)."
            ),
            monitoring = listOf("Signs of tendon pain or inflammation", "Renal function"),
            patientCounselling = listOf("Drink plenty of water daily.", "Stop taking and notify doctor if tendon pain occurs.", "Avoid direct sunlight."),
            advantages = listOf("Potent activity against Gram-negative bacilli including Pseudomonas", "High tissue and urine concentrations"),
            limitations = listOf("Black box warnings for tendon rupture and CNS side effects"),
            memoryTrick = "Cipro-FLOXACIN = FLOXACIN suffix = Fluoroquinolone (inhibits DNA gyrase).",
            references = listOf("CDSCO", "US FDA Prescribing Information")
        ),

        // 8. Cefixime
        MedicineRecord(
            id = "med-008",
            genericName = "Cefixime",
            saltName = "Cefixime Trihydrate",
            activeIngredients = listOf("Cefixime"),
            brandNames = listOf(
                BrandInfo("Zifi 200", "Cefixime", listOf("Cefixime"), "200 mg", "Tablet", "FDC Ltd", false, "Rs. 105 / 10 tabs"),
                BrandInfo("Taxim-O 200", "Cefixime", listOf("Cefixime"), "200 mg", "Tablet", "Alkem Laboratories", false, "Rs. 100 / 10 tabs"),
                BrandInfo("Mahi-O 200", "Cefixime", listOf("Cefixime"), "200 mg", "Tablet", "Mankind", false, "Rs. 95 / 10 tabs")
            ),
            strength = "100 mg / 200 mg",
            dosageForms = listOf("Tablet", "DT (Dispersible Tablet)", "Dry Syrup"),
            routes = listOf("Oral"),
            pronunciation = "sef-IKS-eem",
            romanPronunciation = "Sef-iks-eem",
            hinglishPronunciation = "Kaan, gale aur peshab ki antibiotic (Cefixime)",
            therapeuticClass = "Antibacterial",
            pharmacologicalClass = "Third-Generation Cephalosporin",
            drugClass = "Beta-Lactam Antibiotic",
            atcCode = "J01DD08",
            mechanismOfAction = "Inhibits bacterial cell wall synthesis by binding to penicillin-binding proteins (PBPs), leading to cell lysis in Gram-negative and Gram-positive organisms.",
            indications = listOf("Uncomplicated Urinary Tract Infections", "Otitis Media", "Pharyngitis / Tonsillitis", "Typhoid Fever"),
            uses = listOf("Treating bacterial throat and ear infections", "Managing uncomplicated UTI"),
            contraindications = listOf("Hypersensitivity to cephalosporins or penicillins (severe history)"),
            warnings = listOf("Cross-reactivity in penicillin-allergic patients.", "Risk of C. difficile colitis."),
            precautions = listOf("Reduce dose in patients with severe renal impairment (CrCl < 20 mL/min)."),
            adverseEffects = listOf("Diarrhea", "Loose stools", "Abdominal pain", "Flatulence", "Rash"),
            commonSideEffects = listOf("Loose stools / diarrhea", "Nausea", "Dyspepsia"),
            seriousSideEffects = listOf("Pseudomembranous colitis", "Anaphylaxis", "Neutropenia"),
            drugInteractions = listOf(
                StructuredInteraction("Carbamazepine", "Moderate", "Cefixime increases carbamazepine levels.", "Reduced carbamazepine clearance.", "Monitor carbamazepine levels.")
            ),
            foodInteractions = listOf("Food delays absorption rate slightly but does not affect total absorption."),
            adme = ADMEInfo(
                absorption = "40-50% absorbed from GI tract following oral administration.",
                distribution = "Reaches effective tissue levels in middle ear fluid, sputum, and urine.",
                metabolism = "Not significantly metabolized in the liver.",
                excretion = "50% excreted unchanged in urine within 24 hours. Remainder excreted via biliary system.",
                bioavailability = "40% to 50%",
                proteinBinding = "65%",
                volumeOfDistribution = "0.1 L/kg",
                metabolicPathway = "Renal Excretion Unchanged",
                majorEnzymes = emptyList(),
                halfLife = "3 to 4 hours",
                routeOfElimination = "Renal & Biliary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Considered safe when indicated.",
                pediatric = "Widely used in pediatric oral suspension formulation."
            ),
            monitoring = listOf("Bowel movement frequency", "Renal function in severe renal insufficiency"),
            patientCounselling = listOf("Take dispersible tablets after dissolving completely in water.", "Finish full prescribed course."),
            advantages = listOf("Convenient twice-daily or once-daily oral dosing", "Stable against many beta-lactamase enzymes"),
            limitations = listOf("Moderate oral bioavailability (~45%)"),
            memoryTrick = "CEF-ixime = 3rd Gen CEPHALOSPORIN for ENT and UTI.",
            references = listOf("Indian Pharmacopoeia", "CDSCO")
        ),

        // 9. Cetirizine
        MedicineRecord(
            id = "med-009",
            genericName = "Cetirizine",
            saltName = "Cetirizine Dihydrochloride",
            activeIngredients = listOf("Cetirizine"),
            brandNames = listOf(
                BrandInfo("Cetzine", "Cetirizine", listOf("Cetirizine"), "10 mg", "Tablet", "GSK India", false, "Rs. 22 / 10 tabs"),
                BrandInfo("Okacet", "Cetirizine", listOf("Cetirizine"), "10 mg", "Tablet", "Cipla", false, "Rs. 20 / 10 tabs"),
                BrandInfo("Alerid", "Cetirizine", listOf("Cetirizine"), "10 mg", "Tablet", "Cipla", false, "Rs. 21 / 10 tabs")
            ),
            strength = "5 mg / 10 mg",
            dosageForms = listOf("Tablet", "Syrup"),
            routes = listOf("Oral"),
            pronunciation = "se-TIR-i-zeen",
            romanPronunciation = "Se-tir-i-zeen",
            hinglishPronunciation = "Allergy, cheenk aur khujli ki dawai (Cetirizine)",
            therapeuticClass = "Antiallergic",
            pharmacologicalClass = "Second-Generation H1 Receptor Antagonist",
            drugClass = "Non-Sedating Antihistamine",
            atcCode = "R06AE07",
            mechanismOfAction = "Selectively inhibits peripheral H1 histamine receptors, preventing histamine-mediated allergic responses such as vasodilation, itch, and rhinorrhea.",
            indications = listOf("Allergic Rhinitis (Hay Fever)", "Chronic Idiopathic Urticaria", "Allergic Conjunctivitis"),
            uses = listOf("Relieving sneezing, runny nose, and watery eyes", "Reducing allergic skin itching and hives"),
            contraindications = listOf("End-stage renal disease (CrCl < 10 mL/min)", "Hypersensitivity to hydroxyzine or cetirizine"),
            warnings = listOf("May cause mild somnolence in susceptible individuals.", "Avoid operating heavy machinery if feeling drowsy."),
            precautions = listOf("Reduce dose in moderate to severe renal impairment."),
            adverseEffects = listOf("Somnolence", "Dry mouth", "Fatigue", "Headache"),
            commonSideEffects = listOf("Mild drowsiness", "Dry mouth", "Headache"),
            seriousSideEffects = listOf("Severe hypersensitivity reaction (rare)"),
            drugInteractions = listOf(
                StructuredInteraction("Alcohol / CNS Depressants", "Moderate", "Additive CNS depression and drowsiness.", "Synergistic sedation.", "Avoid alcohol while taking cetirizine.")
            ),
            foodInteractions = listOf("Food delays peak concentration time by ~1.7 hours but does not decrease total absorption."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed. Peak plasma levels in ~1 hour.",
                distribution = "93% bound to plasma proteins. Poor blood-brain barrier penetration compared to 1st gen antihistamines.",
                metabolism = "Metabolized to a limited extent by oxidative O-dealkylation.",
                excretion = "70% excreted in urine unchanged within 72 hours, 10% in feces.",
                bioavailability = "70%",
                proteinBinding = "93%",
                volumeOfDistribution = "0.5 L/kg",
                metabolicPathway = "Minimal Hepatic Metabolism",
                majorEnzymes = emptyList(),
                halfLife = "8.3 hours",
                routeOfElimination = "Renal (Urinary)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Considered safe if needed during pregnancy.",
                lactation = "Excreted in human milk; levocetirizine/loratadine may be preferred."
            ),
            monitoring = listOf("Symptom relief assessment", "Drowsiness monitoring"),
            patientCounselling = listOf("Take once daily, preferably in the evening.", "Caution while driving if drowsiness occurs."),
            advantages = listOf("Rapid onset of action (<1 hour)", "Minimal cardiotoxicity and low drug-interaction risk"),
            limitations = listOf("Slightly more sedating than loratadine or fexofenadine"),
            memoryTrick = "Ceti-RIZINE = 2nd Gen H1 Blocker for Rhinitis & Itching.",
            references = listOf("Indian Pharmacopoeia", "CDSCO List")
        ),

        // 10. Levocetirizine
        MedicineRecord(
            id = "med-010",
            genericName = "Levocetirizine",
            saltName = "Levocetirizine Dihydrochloride",
            activeIngredients = listOf("Levocetirizine"),
            brandNames = listOf(
                BrandInfo("Lutec 5", "Levocetirizine", listOf("Levocetirizine"), "5 mg", "Tablet", "Sun Pharma", false, "Rs. 50 / 10 tabs"),
                BrandInfo("Monticope", "Levocetirizine + Montelukast", listOf("Levocetirizine", "Montelukast"), "5 mg + 10 mg", "Tablet", "Mankind Pharma", true, "Rs. 120 / 10 tabs"),
                BrandInfo("Telekast-L", "Levocetirizine + Montelukast", listOf("Levocetirizine", "Montelukast"), "5 mg + 10 mg", "Tablet", "Lupin", true, "Rs. 135 / 10 tabs")
            ),
            strength = "5 mg",
            dosageForms = listOf("Tablet", "Syrup"),
            routes = listOf("Oral"),
            pronunciation = "lee-voe-se-TIR-i-zeen",
            romanPronunciation = "Lee-vo-se-tir-i-zeen",
            hinglishPronunciation = "Allergy aur nazla ki dawai (Levocetirizine)",
            therapeuticClass = "Antiallergic",
            pharmacologicalClass = "R-Enantiomer of Cetirizine (2nd Gen Antihistamine)",
            drugClass = "Selective H1 Receptor Antagonist",
            atcCode = "R06AE09",
            mechanismOfAction = "Active R-enantiomer of cetirizine. Binds with higher affinity to peripheral H1 receptors, blocking histamine activity.",
            indications = listOf("Allergic Rhinitis", "Chronic Urticaria", "Perennial Allergic Rhinitis"),
            uses = listOf("Relieving nasal congestion, itching, sneezing", "Managing allergic skin reactions"),
            contraindications = listOf("End-stage renal disease (CrCl < 10 mL/min)", "Children 6 months-11 years with impaired renal function"),
            warnings = listOf("Avoid concurrent alcohol or sedatives due to CNS depression risk."),
            precautions = listOf("Dose reduction needed in renal insufficiency."),
            adverseEffects = listOf("Somnolence", "Nasopharyngitis", "Dry mouth", "Fatigue"),
            commonSideEffects = listOf("Mild drowsiness", "Dry mouth"),
            seriousSideEffects = listOf("Severe hypersensitivity (rare)"),
            drugInteractions = listOf(
                StructuredInteraction("Ritonavir", "Moderate", "Increases levocetirizine AUC due to reduced clearance.", "Transporter inhibition.", "Monitor for sedation.")
            ),
            foodInteractions = listOf("Can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed. Peak levels in 0.9 hours.",
                distribution = "90% plasma protein bound. Low volume of distribution.",
                metabolism = "< 14% hepatic metabolism via aromatic oxidation and glucuronidation.",
                excretion = "85% renal excretion unchanged.",
                bioavailability = "High (~85%)",
                proteinBinding = "90%",
                volumeOfDistribution = "0.4 L/kg",
                metabolicPathway = "Renal Excretion Unchanged",
                majorEnzymes = listOf("CYP3A4"),
                halfLife = "8 to 9 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Preferred choice when antihistamine is required."
            ),
            monitoring = listOf("Allergy symptom reduction", "Renal parameters in elderly"),
            patientCounselling = listOf("Take at bedtime to avoid daytime sleepiness."),
            advantages = listOf("Twice the affinity for H1 receptor compared to racemic cetirizine", "Lower dose needed (5 mg vs 10 mg)"),
            limitations = listOf("May still cause mild drowsiness in sensitive users"),
            memoryTrick = "LEVO-cetirizine = Active LEVO isomer of cetirizine (5 mg potency).",
            references = listOf("CDSCO Approved List", "British National Formulary")
        ),

        // 11. Omeprazole
        MedicineRecord(
            id = "med-011",
            genericName = "Omeprazole",
            saltName = "Omeprazole Magnesium / Base",
            activeIngredients = listOf("Omeprazole"),
            brandNames = listOf(
                BrandInfo("Omez 20", "Omeprazole", listOf("Omeprazole"), "20 mg", "Capsule", "Dr. Reddy's", false, "Rs. 60 / 15 caps"),
                BrandInfo("Omez-D", "Omeprazole + Domperidone", listOf("Omeprazole", "Domperidone"), "20 mg + 10 mg", "Capsule", "Dr. Reddy's", true, "Rs. 140 / 15 caps")
            ),
            strength = "20 mg / 40 mg",
            dosageForms = listOf("Capsule", "Tablet", "Injection"),
            routes = listOf("Oral", "Intravenous"),
            pronunciation = "oh-MEP-ra-zole",
            romanPronunciation = "O-mep-ra-zole",
            hinglishPronunciation = "Tezab aur acidity ki dawai (Omeprazole PPI)",
            therapeuticClass = "Gastroprotective",
            pharmacologicalClass = "Proton Pump Inhibitor (PPI)",
            drugClass = "Substituted Benzimidazole",
            atcCode = "A02BC01",
            mechanismOfAction = "Irreversibly inhibits H+/K+ ATPase pump in parietal cells, shutting down terminal step of gastric acid secretion.",
            indications = listOf("GERD (Gastroesophageal Reflux)", "Peptic Ulcer Disease", "H. pylori Eradication", "Zollinger-Ellison Syndrome"),
            uses = listOf("Relieving heartburn and hyperacidity", "Healing stomach and duodenal ulcers"),
            contraindications = listOf("Co-administration with nelfinavir or rilpivirine", "Known hypersensitivity to substituted benzimidazoles"),
            warnings = listOf("Long-term use associated with Vitamin B12 deficiency, hypomagnesemia, and bone fractures.", "Risk of C. difficile diarrhea."),
            precautions = listOf("Take 30-60 minutes before first meal of the day for optimal effect."),
            adverseEffects = listOf("Headache", "Abdominal pain", "Nausea", "Diarrhea", "Flatulence", "Vitamin B12 deficiency (long term)"),
            commonSideEffects = listOf("Headache", "Flatulence", "Mild diarrhea"),
            seriousSideEffects = listOf("Severe hypomagnesemia", "Osteoporotic bone fracture", "Clostridium difficile colitis"),
            drugInteractions = listOf(
                StructuredInteraction("Clopidogrel", "Major", "Omeprazole inhibits CYP2C19, reducing activation of clopidogrel.", "CYP2C19 inhibition.", "Avoid combination or use pantoprazole instead."),
                StructuredInteraction("Ketoconazole", "Major", "Reduced absorption of antifungal due to elevated gastric pH.", "pH-dependent solubility.", "Avoid or monitor response.")
            ),
            foodInteractions = listOf("Take on empty stomach 30-60 minutes before breakfast."),
            adme = ADMEInfo(
                absorption = "Acid-labile; formulated as enteric-coated granules. Bioavailability increases with repeated dosing.",
                distribution = "95% bound to plasma proteins. Concentrated in parietal cell canaliculi.",
                metabolism = "Extensive hepatic metabolism via CYP2C19 and CYP3A4 to inactive hydroxy and sulfone metabolites.",
                excretion = "80% excreted in urine, 20% in feces.",
                bioavailability = "35% (initial dose) to 60% (repeated dosing)",
                proteinBinding = "95%",
                volumeOfDistribution = "0.3 L/kg",
                metabolicPathway = "CYP2C19 & CYP3A4 Oxidation",
                majorEnzymes = listOf("CYP2C19", "CYP3A4"),
                halfLife = "0.5 to 1 hour (antisecretory effect lasts 24+ hours due to irreversible binding)",
                routeOfElimination = "Urinary & Fecal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Rabeprazole or Pantoprazole preferred if PPI needed.",
                geriatric = "No routine dose adjustment required; check bone density in long-term use."
            ),
            monitoring = listOf("Serum magnesium in therapy > 1 year", "Bone mineral density in high-risk elderly"),
            patientCounselling = listOf("Swallow whole with water; do not crush or chew capsule granules.", "Take 30 minutes before breakfast."),
            advantages = listOf("Profound and prolonged inhibition of gastric acid", "Established safety record over decades"),
            limitations = listOf("Strong CYP2C19 inhibition causes drug interaction with clopidogrel"),
            memoryTrick = "-PRAZOLE suffix = Proton Pump Inhibitor (PPI) for Acidity.",
            references = listOf("CDSCO Approved Drug List", "Indian Pharmacopoeia")
        ),

        // 12. Pantoprazole
        MedicineRecord(
            id = "med-012",
            genericName = "Pantoprazole",
            saltName = "Pantoprazole Sodium",
            activeIngredients = listOf("Pantoprazole"),
            brandNames = listOf(
                BrandInfo("Pan 40", "Pantoprazole", listOf("Pantoprazole"), "40 mg", "Tablet", "Alkem Laboratories", false, "Rs. 155 / 15 tabs"),
                BrandInfo("Pantocid 40", "Pantoprazole", listOf("Pantoprazole"), "40 mg", "Tablet", "Sun Pharma", false, "Rs. 160 / 15 tabs"),
                BrandInfo("Pan-D", "Pantoprazole + Domperidone", listOf("Pantoprazole", "Domperidone"), "40 mg + 30 mg SR", "Capsule", "Alkem", true, "Rs. 190 / 15 caps")
            ),
            strength = "20 mg / 40 mg",
            dosageForms = listOf("Tablet", "Injection"),
            routes = listOf("Oral", "Intravenous"),
            pronunciation = "pan-TOE-pra-zole",
            romanPronunciation = "Pan-to-pra-zole",
            hinglishPronunciation = "Gerd aur gas ki dawai (Pantoprazole)",
            therapeuticClass = "Gastroprotective",
            pharmacologicalClass = "Proton Pump Inhibitor (PPI)",
            drugClass = "Substituted Benzimidazole",
            atcCode = "A02BC02",
            mechanismOfAction = "Suppresses final step of gastric acid production by covalently inhibiting H+/K+ ATPase enzyme system in stomach parietal cells.",
            indications = listOf("GERD", "Erosive Esophagitis", "Peptic Ulcers", "Stress Ulcer Prophylaxis in ICU"),
            uses = listOf("Treating severe acid reflux and gas", "Preventing stomach ulcers from painkillers"),
            contraindications = listOf("Hypersensitivity to pantoprazole or other benzimidazoles"),
            warnings = listOf("Risk of bone fracture, hypomagnesemia, and C. difficile diarrhea in long-term therapy."),
            precautions = listOf("Take 30 minutes before morning meal for best inhibition."),
            adverseEffects = listOf("Headache", "Diarrhea", "Nausea", "Abdominal pain", "Flatulence"),
            commonSideEffects = listOf("Headache", "Loose stools"),
            seriousSideEffects = listOf("Acute interstitial nephritis", "Subacute cutaneous lupus erythematosus"),
            drugInteractions = listOf(
                StructuredInteraction("Clopidogrel", "Minor", "Pantoprazole has minimal CYP2C19 inhibition compared to omeprazole.", "Lesser enzymatic interference.", "Preferred PPI in patients taking clopidogrel.")
            ),
            foodInteractions = listOf("Take 30 minutes before meals."),
            adme = ADMEInfo(
                absorption = "Well absorbed. Peak plasma levels in 2.5 hours.",
                distribution = "98% bound to plasma proteins.",
                metabolism = "Extensively metabolized in liver by CYP2C19 demethylation and sulfation.",
                excretion = "71% renal excretion, 18% fecal excretion.",
                bioavailability = "77%",
                proteinBinding = "98%",
                volumeOfDistribution = "0.15 L/kg",
                metabolicPathway = "CYP2C19 Demethylation & Sulfation",
                majorEnzymes = listOf("CYP2C19", "CYP3A4"),
                halfLife = "1 hour",
                routeOfElimination = "Renal & Fecal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Considered safer choice among PPIs."
            ),
            monitoring = listOf("Serum magnesium in prolonged therapy"),
            patientCounselling = listOf("Do not split or crush enteric-coated tablets.", "Take in morning before food."),
            advantages = listOf("Lowest CYP2C19 interaction potential among PPIs", "Safe to co-administer with clopidogrel"),
            limitations = listOf("Long-term hypomagnesemia and fracture risk common to all PPIs"),
            memoryTrick = "PAN-toprazole = PREFERRED PPI with lowest drug interaction profile.",
            references = listOf("CDSCO", "Indian Pharmacopoeia")
        ),

        // 13. Metformin
        MedicineRecord(
            id = "med-013",
            genericName = "Metformin",
            saltName = "Metformin Hydrochloride",
            activeIngredients = listOf("Metformin"),
            brandNames = listOf(
                BrandInfo("Glycomet 500", "Metformin", listOf("Metformin"), "500 mg", "Tablet", "USV Ltd", false, "Rs. 25 / 10 tabs"),
                BrandInfo("Glycomet SR 500", "Metformin SR", listOf("Metformin"), "500 mg", "SR Tablet", "USV Ltd", false, "Rs. 30 / 10 tabs"),
                BrandInfo("Glycomet GP 1", "Metformin + Glimepiride", listOf("Metformin", "Glimepiride"), "500 mg + 1 mg", "Tablet", "USV Ltd", true, "Rs. 55 / 10 tabs")
            ),
            strength = "500 mg / 850 mg / 1000 mg",
            dosageForms = listOf("Tablet", "SR Tablet"),
            routes = listOf("Oral"),
            pronunciation = "met-FOR-min",
            romanPronunciation = "Met-for-min",
            hinglishPronunciation = "Sugar aur diabetes ki pehli dawai (Metformin)",
            therapeuticClass = "Antidiabetic",
            pharmacologicalClass = "Biguanide",
            drugClass = "Insulin Sensitizer",
            atcCode = "A10BA02",
            mechanismOfAction = "Activates AMP-activated protein kinase (AMPK), reducing hepatic gluconeogenesis, decreasing intestinal glucose absorption, and enhancing peripheral insulin sensitivity.",
            indications = listOf("Type 2 Diabetes Mellitus", "Polycystic Ovary Syndrome (PCOS)", "Prediabetes"),
            uses = listOf("First-line treatment for blood sugar control in Type 2 Diabetes", "Improving insulin sensitivity in PCOS"),
            contraindications = listOf("Severe renal impairment (eGFR < 30 mL/min)", "Acute metabolic acidosis / Diabetic ketoacidosis", "Severe tissue hypoxia / shock"),
            warnings = listOf("Black Box Warning: Risk of Lactic Acidosis (rare but fatal).", "Withhold prior to iodinated contrast dye procedures."),
            precautions = listOf("Monitor eGFR before initiating and at least annually.", "Assess Vitamin B12 levels in long-term therapy."),
            adverseEffects = listOf("Diarrhea", "Nausea", "Abdominal bloating", "Metallic taste", "Vitamin B12 deficiency", "Lactic acidosis (rare)"),
            commonSideEffects = listOf("Diarrhea / loose stools", "Nausea", "Abdominal discomfort"),
            seriousSideEffects = listOf("Lactic acidosis", "Severe B12 deficiency anemia"),
            drugInteractions = listOf(
                StructuredInteraction("Iodinated Contrast Media", "Major", "Increases risk of acute renal failure and lactic acidosis.", "Renal contrast toxicity.", "Withhold metformin at time of or prior to contrast procedure."),
                StructuredInteraction("Alcohol", "Major", "Potentiates effect of metformin on lactate metabolism.", "Increased lactic acidosis risk.", "Avoid excessive alcohol intake.")
            ),
            foodInteractions = listOf("Take with meals to reduce gastrointestinal side effects."),
            adme = ADMEInfo(
                absorption = "Absorbed slowly from small intestine. Absolute bioavailability ~50-60%.",
                distribution = "Negligible plasma protein binding. Accumulates in salivary glands, liver, and kidney.",
                metabolism = "Not metabolized by the liver. Excreted completely unchanged.",
                excretion = "Renal tubular secretion (100% unchanged in urine).",
                bioavailability = "50% to 60%",
                proteinBinding = "Negligible (0%)",
                volumeOfDistribution = "654 L (tissue accumulation)",
                metabolicPathway = "None (Excreted Unchanged)",
                majorEnzymes = emptyList(),
                halfLife = "6.2 hours (plasma), 17.6 hours (terminal elimination)",
                routeOfElimination = "Renal (Urinary)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category B. Widely used in gestational diabetes under expert care.",
                geriatric = "Dose titration based on eGFR; avoid if eGFR < 30 mL/min."
            ),
            monitoring = listOf("HbA1c every 3-6 months", "Serum creatinine / eGFR", "Vitamin B12 levels every 1-2 years"),
            patientCounselling = listOf("Take with meals to avoid stomach upset.", "Report muscle pain, weakness, or trouble breathing immediately."),
            advantages = listOf("Does not cause hypoglycemia when used as monotherapy", "Weight-neutral or modest weight loss benefit", "Cardiovascular protection"),
            limitations = listOf("GI intolerance (diarrhea/gas) in early weeks", "Lactic acidosis risk in renal failure"),
            memoryTrick = "MET-formin = METABOLIC AMPK activator for Type 2 Diabetes.",
            references = listOf("ADA Standards of Medical Care in Diabetes", "Indian Council of Medical Research (ICMR) Guidelines")
        ),

        // 14. Telmisartan
        MedicineRecord(
            id = "med-014",
            genericName = "Telmisartan",
            saltName = "Telmisartan",
            activeIngredients = listOf("Telmisartan"),
            brandNames = listOf(
                BrandInfo("Telma 40", "Telmisartan", listOf("Telmisartan"), "40 mg", "Tablet", "Glenmark Pharma", false, "Rs. 90 / 15 tabs"),
                BrandInfo("Telmikind 40", "Telmisartan", listOf("Telmisartan"), "40 mg", "Tablet", "Mankind Pharma", false, "Rs. 45 / 10 tabs"),
                BrandInfo("Telma H", "Telmisartan + Hydrochlorothiazide", listOf("Telmisartan", "Hydrochlorothiazide"), "40 mg + 12.5 mg", "Tablet", "Glenmark", true, "Rs. 110 / 15 tabs"),
                BrandInfo("Telma AM", "Telmisartan + Amlodipine", listOf("Telmisartan", "Amlodipine"), "40 mg + 5 mg", "Tablet", "Glenmark", true, "Rs. 130 / 15 tabs")
            ),
            strength = "20 mg / 40 mg / 80 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "tel-mi-SAR-tan",
            romanPronunciation = "Tel-mi-sar-tan",
            hinglishPronunciation = "BP aur high blood pressure ki dawai (Telmisartan ARB)",
            therapeuticClass = "Antihypertensive",
            pharmacologicalClass = "Angiotensin II Receptor Blocker (ARB)",
            drugClass = "AT1 Receptor Antagonist",
            atcCode = "C09CA07",
            mechanismOfAction = "Selectively blocks Angiotensin II from binding to the AT1 receptor in vascular smooth muscle and adrenal gland, causing vasodilation and reduced aldosterone secretion. Also acts as a partial agonist of PPAR-gamma.",
            indications = listOf("Essential Hypertension", "Cardiovascular Risk Reduction", "Diabetic Nephropathy"),
            uses = listOf("Lowering high blood pressure", "Protecting kidneys in diabetic hypertensive patients"),
            contraindications = listOf("Pregnancy (2nd and 3rd trimesters)", "Biliary obstructive disorders", "Co-administration with aliskiren in diabetic patients"),
            warnings = listOf("Black Box Warning: Fetal Toxicity. Discontinue immediately when pregnancy is detected.", "Risk of hyperkalemia and hypotension."),
            precautions = listOf("Monitor serum potassium and renal function regularly."),
            adverseEffects = listOf("Dizziness", "Hyperkalemia", "Back pain", "Sinusitis", "Renal dysfunction"),
            commonSideEffects = listOf("Dizziness / lightheadedness", "Back pain"),
            seriousSideEffects = listOf("Fetal malformation/death", "Severe hyperkalemia", "Acute kidney injury"),
            drugInteractions = listOf(
                StructuredInteraction("Potassium Supplements / Spironolactone", "Major", "Increased risk of severe hyperkalemia.", "Additive potassium retention.", "Avoid routine co-administration or monitor serum potassium closely."),
                StructuredInteraction("Lithium", "Major", "Increases serum lithium concentrations and toxicity.", "Reduced renal lithium clearance.", "Monitor lithium levels.")
            ),
            foodInteractions = listOf("Can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Absorbed rapidly. Bioavailability is dose-dependent (~42-58%).",
                distribution = "Extensively bound to plasma proteins (>99.5%). High volume of distribution.",
                metabolism = "Metabolized by glucuronidation to inactive telmisartan 1-O-acylglucuronide.",
                excretion = "Almost exclusively excreted via feces (>97%) via biliary secretion. < 1% in urine.",
                bioavailability = "42% to 58%",
                proteinBinding = "> 99.5%",
                volumeOfDistribution = "500 L (high tissue binding)",
                metabolicPathway = "Hepatic Glucuronidation (No CYP participation)",
                majorEnzymes = listOf("UGT1A3"),
                halfLife = "24 hours (longest half-life among ARBs)",
                routeOfElimination = "Biliary (Fecal)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Contraindicated (Fetal toxicity and renal dysgenesis).",
                lactation = "Excreted in animal milk; not recommended during breastfeeding."
            ),
            monitoring = listOf("Blood pressure", "Serum potassium and creatinine within 2 weeks of starting"),
            patientCounselling = listOf("Take once daily at approximately the same time.", "Do not take potassium supplements without medical advice."),
            advantages = listOf("Long 24-hour half-life provides full 24-hour BP control including early morning surge", "Dual PPAR-gamma activity improves insulin sensitivity"),
            limitations = listOf("Contraindicated in pregnancy"),
            memoryTrick = "-SARTAN suffix = Selective Angiotensin Receptor Blocker for BP.",
            references = listOf("CDSCO Approved Drug List", "Indian Hypertension Guidelines (IHG)")
        ),

        // 15. Amlodipine
        MedicineRecord(
            id = "med-015",
            genericName = "Amlodipine",
            saltName = "Amlodipine Besylate",
            activeIngredients = listOf("Amlodipine"),
            brandNames = listOf(
                BrandInfo("Amlokind 5", "Amlodipine", listOf("Amlodipine"), "5 mg", "Tablet", "Mankind Pharma", false, "Rs. 20 / 10 tabs"),
                BrandInfo("Stamlo 5", "Amlodipine", listOf("Amlodipine"), "5 mg", "Tablet", "Reddy's", false, "Rs. 32 / 10 tabs"),
                BrandInfo("Amlopin 5", "Amlodipine", listOf("Amlodipine"), "5 mg", "Tablet", "Cipla", false, "Rs. 30 / 10 tabs")
            ),
            strength = "2.5 mg / 5 mg / 10 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "am-LOE-di-peen",
            romanPronunciation = "Am-lo-di-peen",
            hinglishPronunciation = "High BP aur dil ki naliyon ko kholne ki dawai (Amlodipine)",
            therapeuticClass = "Antihypertensive & Antianginal",
            pharmacologicalClass = "Dihydropyridine Calcium Channel Blocker (CCB)",
            drugClass = "L-type Calcium Channel Antagonist",
            atcCode = "C08CA01",
            mechanismOfAction = "Inhibits transmembrane influx of calcium ions into vascular smooth muscle and cardiac muscle, producing peripheral arterial vasodilation and reducing total peripheral resistance.",
            indications = listOf("Essential Hypertension", "Chronic Stable Angina", "Vasospastic (Prinzmetal's) Angina"),
            uses = listOf("Lowering blood pressure", "Preventing chest pain (angina) on exertion"),
            contraindications = listOf("Severe hypotension", "Aortic stenosis", "Unstable heart failure after acute MI"),
            warnings = listOf("Worsening angina or acute MI upon initiation or dose increase (rare)."),
            precautions = listOf("Pedal edema (ankle swelling) is dose-dependent.", "Use caution in severe hepatic impairment."),
            adverseEffects = listOf("Peripheral edema (ankle swelling)", "Flushing", "Dizziness", "Palpitations", "Gingival hyperplasia"),
            commonSideEffects = listOf("Ankle swelling", "Flushing / feeling warm", "Dizziness"),
            seriousSideEffects = listOf("Severe hypotension", "Reflex tachycardia (rare)"),
            drugInteractions = listOf(
                StructuredInteraction("Simvastatin", "Major", "Amlodipine increases simvastatin exposure; limit simvastatin dose to 20 mg daily.", "CYP3A4 competition.", "Limit simvastatin dose."),
                StructuredInteraction("Grapefruit Juice", "Moderate", "Increases amlodipine plasma concentration.", "CYP3A4 inhibition.", "Avoid excessive grapefruit juice.")
            ),
            foodInteractions = listOf("Can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Slowly and almost completely absorbed. Peak plasma level in 6-12 hours.",
                distribution = "97.5% bound to circulating plasma proteins. Large volume of distribution.",
                metabolism = "Extensive hepatic metabolism to inactive metabolites (~90%) via CYP3A4.",
                excretion = "60% excreted in urine (10% unchanged), 20-25% in feces.",
                bioavailability = "64% to 90%",
                proteinBinding = "97.5%",
                volumeOfDistribution = "21 L/kg",
                metabolicPathway = "Hepatic CYP3A4 Oxidation",
                majorEnzymes = listOf("CYP3A4"),
                halfLife = "30 to 50 hours (enables once-daily dosing)",
                routeOfElimination = "Urinary & Fecal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Used when benefits outweigh risks.",
                geriatric = "Lower initial dose (2.5 mg daily) recommended."
            ),
            monitoring = listOf("Blood pressure", "Ankle edema assessment"),
            patientCounselling = listOf("Take once daily.", "If ankle swelling occurs, elevate feet or consult your physician."),
            advantages = listOf("Long half-life (30-50h) ensures smooth 24h BP control without abrupt drop", "Does not cause rebound hypertension on missed dose"),
            limitations = listOf("High incidence of peripheral pedal edema at 10 mg dose"),
            memoryTrick = "-DIPINE suffix = Dihydropyridine Calcium Channel Blocker for Vasodilation.",
            references = listOf("CDSCO Approved Drug List", "Indian Pharmacopoeia")
        )
    )
}
