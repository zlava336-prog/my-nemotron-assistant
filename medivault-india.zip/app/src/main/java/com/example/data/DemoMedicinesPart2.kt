package com.example.data

import com.example.model.*

object DemoMedicinesPart2 {
    val list = listOf(
        // 16. Atenolol
        MedicineRecord(
            id = "med-016",
            genericName = "Atenolol",
            saltName = "Atenolol",
            activeIngredients = listOf("Atenolol"),
            brandNames = listOf(
                BrandInfo("Aten 50", "Atenolol", listOf("Atenolol"), "50 mg", "Tablet", "Zydus Healthcare", false, "Rs. 28 / 14 tabs"),
                BrandInfo("Tenormin 50", "Atenolol", listOf("Atenolol"), "50 mg", "Tablet", "Abbott India", false, "Rs. 45 / 14 tabs")
            ),
            strength = "25 mg / 50 mg / 100 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "ah-TEN-oh-lol",
            romanPronunciation = "A-ten-o-lol",
            hinglishPronunciation = "Dil ki dhadkan aur high BP ki dawai (Atenolol Beta Blocker)",
            therapeuticClass = "Antihypertensive & Antianginal",
            pharmacologicalClass = "Cardioselective Beta-1 Adrenergic Receptor Antagonist",
            drugClass = "Beta Blocker (Selective)",
            atcCode = "C07AB03",
            mechanismOfAction = "Competitively blocks beta-1 adrenergic receptors in heart tissue, reducing heart rate, cardiac contractility, cardiac output, and blood pressure.",
            indications = listOf("Hypertension", "Angina Pectoris", "Cardiac Arrhythmias", "Post-Myocardial Infarction"),
            uses = listOf("Slowing down rapid heart rate", "Lowering elevated blood pressure", "Preventing angina chest pain"),
            contraindications = listOf("Sinus bradycardia (HR < 50 bpm)", "Second or third-degree AV block", "Cardiogenic shock", "Severe peripheral arterial disease"),
            warnings = listOf("Do not abruptly stop taking atenolol; sudden withdrawal can precipitate angina, arrhythmia, or myocardial infarction."),
            precautions = listOf("Use with caution in diabetic patients (may mask hypoglycemia symptoms like tachycardia)."),
            adverseEffects = listOf("Bradycardia", "Cold extremities", "Fatigue", "Dizziness", "Bronchospasm (at high doses)"),
            commonSideEffects = listOf("Cold hands and feet", "Fatigue", "Slow heart rate"),
            seriousSideEffects = listOf("Severe bradycardia", "AV block", "Heart failure exacerbation"),
            drugInteractions = listOf(
                StructuredInteraction("Verapamil / Diltiazem", "Major", "Severe bradycardia and AV block risk.", "Additive SA and AV node inhibition.", "Avoid co-administration or monitor heart rate and ECG."),
                StructuredInteraction("Insulin", "Moderate", "Masks symptoms of hypoglycemia except sweating.", "Sympathetic inhibition.", "Educate patient to rely on diaphoresis.")
            ),
            foodInteractions = listOf("Can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Incompletely absorbed (~50%). Peak plasma level in 2-4 hours.",
                distribution = "Low lipid solubility (hydrophilic); poor penetration across blood-brain barrier.",
                metabolism = "Little or no hepatic metabolism.",
                excretion = "85% excreted unchanged in urine.",
                bioavailability = "50%",
                proteinBinding = "6% to 16%",
                volumeOfDistribution = "0.7 L/kg",
                metabolicPathway = "Excreted Unchanged in Urine",
                majorEnzymes = emptyList(),
                halfLife = "6 to 7 hours",
                routeOfElimination = "Renal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category D. Intrauterine growth restriction reported.",
                geriatric = "Dose reduction in renal clearance decline."
            ),
            monitoring = listOf("Heart rate and blood pressure before each dose", "Renal function"),
            patientCounselling = listOf("Check your pulse regularly.", "Do not stop taking abruptly without consulting doctor."),
            advantages = listOf("Water soluble; minimal CNS side effects (less sleep disturbance/nightmares compared to propranolol)"),
            limitations = listOf("Hydrophilic nature requires renal clearance adjustment"),
            memoryTrick = "-LOL suffix = Beta-Adrenergic Blocker for heart rate & BP.",
            references = listOf("CDSCO", "Indian Pharmacopoeia")
        ),

        // 17. Metoprolol
        MedicineRecord(
            id = "med-017",
            genericName = "Metoprolol",
            saltName = "Metoprolol Succinate / Tartrate",
            activeIngredients = listOf("Metoprolol"),
            brandNames = listOf(
                BrandInfo("Metolar XR 25", "Metoprolol Succinate", listOf("Metoprolol"), "25 mg", "PR Tablet", "Cipla", false, "Rs. 70 / 10 tabs"),
                BrandInfo("Met XL 50", "Metoprolol Succinate", listOf("Metoprolol"), "50 mg", "PR Tablet", "Ajanta Pharma", false, "Rs. 110 / 10 tabs"),
                BrandInfo("Starpress XL 25", "Metoprolol Succinate", listOf("Metoprolol"), "25 mg", "PR Tablet", "Lupin", false, "Rs. 65 / 10 tabs")
            ),
            strength = "12.5 mg / 25 mg / 50 mg / 100 mg",
            dosageForms = listOf("Tablet", "PR/XR Tablet", "Injection"),
            routes = listOf("Oral", "Intravenous"),
            pronunciation = "me-TOE-pro-lol",
            romanPronunciation = "Me-to-pro-lol",
            hinglishPronunciation = "Dil ke daure aur high BP ki dawai (Metoprolol Beta Blocker)",
            therapeuticClass = "Cardiovascular Agent",
            pharmacologicalClass = "Cardioselective Beta-1 Adrenergic Blocker",
            drugClass = "Beta-1 Selective Antagonist",
            atcCode = "C07AB02",
            mechanismOfAction = "Inhibits beta-1 adrenergic receptors in cardiac tissue, reducing heart rate, AV conduction, and myocardial oxygen demand.",
            indications = listOf("Heart Failure (Metoprolol Succinate Extended Release)", "Hypertension", "Angina Pectoris", "Post-MI Mortality Reduction"),
            uses = listOf("Improving survival in chronic heart failure", "Lowering heart rate in tachycardia"),
            contraindications = listOf("Severe bradycardia", "Second/third degree AV block", "Decompensated heart failure"),
            warnings = listOf("Black Box Warning: Sudden discontinuation can cause severe angina exacerbation or heart attack."),
            precautions = listOf("Lipophilic drug; can cross blood-brain barrier."),
            adverseEffects = listOf("Dizziness", "Fatigue", "Bradycardia", "Depression", "Shortness of breath"),
            commonSideEffects = listOf("Tiredness", "Slow heart rate", "Cold fingers"),
            seriousSideEffects = listOf("Decompensated heart failure", "Severe bronchospasm"),
            drugInteractions = listOf(
                StructuredInteraction("Paroxetine / Fluoxetine", "Major", "Potent CYP2D6 inhibitors increase metoprolol concentrations significantly.", "CYP2D6 inhibition.", "Monitor heart rate; lower metoprolol dose.")
            ),
            foodInteractions = listOf("Tartrate formulation absorption increases with food; Succinate ER formulation can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Rapid and almost complete absorption. Extensive first-pass metabolism (~50%).",
                distribution = "Lipophilic; crosses blood-brain barrier. 12% protein bound.",
                metabolism = "Extensive hepatic metabolism via CYP2D6.",
                excretion = "95% excreted in urine as inactive metabolites.",
                bioavailability = "50% (Tartrate) to 40% (Succinate)",
                proteinBinding = "12%",
                volumeOfDistribution = "3.2 to 5.6 L/kg",
                metabolicPathway = "Hepatic CYP2D6 Hydroxylation",
                majorEnzymes = listOf("CYP2D6"),
                halfLife = "3 to 7 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Preferred beta blocker in heart failure."
            ),
            monitoring = listOf("Heart rate", "Blood pressure", "Signs of heart failure worsening"),
            patientCounselling = listOf("Do not break or crush XL tablets unless scored.", "Never stop taking suddenly."),
            advantages = listOf("Metoprolol Succinate ER is proven to reduce mortality in chronic heart failure (MERIT-HF trial)"),
            limitations = listOf("Lipophilicity can lead to central nervous system effects (insomnia/vivid dreams)"),
            memoryTrick = "METO-prolol = METABOLIZED by CYP2D6, MORTALITY reduction in Heart Failure.",
            references = listOf("AHA/ACC Heart Failure Guidelines", "CDSCO")
        ),

        // 18. Enalapril
        MedicineRecord(
            id = "med-018",
            genericName = "Enalapril",
            saltName = "Enalapril Maleate",
            activeIngredients = listOf("Enalapril"),
            brandNames = listOf(
                BrandInfo("Enam 5", "Enalapril", listOf("Enalapril"), "5 mg", "Tablet", "Dr. Reddy's", false, "Rs. 30 / 10 tabs"),
                BrandInfo("Vasotec 5", "Enalapril", listOf("Enalapril"), "5 mg", "Tablet", "MSD India", false, "Rs. 45 / 10 tabs")
            ),
            strength = "2.5 mg / 5 mg / 10 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "e-NAL-ah-pril",
            romanPronunciation = "E-nal-a-pril",
            hinglishPronunciation = "Dil aur high BP ki dawai (Enalapril ACE Inhibitor)",
            therapeuticClass = "Antihypertensive",
            pharmacologicalClass = "Angiotensin-Converting Enzyme (ACE) Inhibitor",
            drugClass = "ACE Inhibitor (Prodrug)",
            atcCode = "C09AA02",
            mechanismOfAction = "Prodrug bioactivated to enalaprilat, which competitively inhibits ACE, preventing conversion of Angiotensin I to Angiotensin II and decreasing bradykinin breakdown.",
            indications = listOf("Hypertension", "Heart Failure", "Asymptomatic Left Ventricular Dysfunction"),
            uses = listOf("Lowering blood pressure", "Preventing heart enlargement and weakness after heart attack"),
            contraindications = listOf("History of ACE inhibitor-induced angioedema", "Pregnancy", "Concomitant sacubitril/valsartan or aliskiren"),
            warnings = listOf("Black Box Warning: Fetal Toxicity. Discontinue as soon as pregnancy is detected.", "Risk of life-threatening angioedema."),
            precautions = listOf("Dry cough is a common class effect due to accumulation of bradykinin."),
            adverseEffects = listOf("Dry persistent cough", "Hyperkalemia", "Dizziness", "Hypotension", "Angioedema"),
            commonSideEffects = listOf("Dry tickly cough", "Dizziness"),
            seriousSideEffects = listOf("Laryngeal angioedema", "Agranulocytosis", "Acute kidney injury in bilateral renal artery stenosis"),
            drugInteractions = listOf(
                StructuredInteraction("Spironolactone", "Major", "Severe hyperkalemia risk.", "Additive potassium conservation.", "Monitor serum potassium."),
                StructuredInteraction("NSAIDs", "Moderate", "Attenuates antihypertensive effect and increases acute renal injury risk.", "Prostaglandin inhibition.", "Monitor BP and renal function.")
            ),
            foodInteractions = listOf("Can be taken without regard to meals."),
            adme = ADMEInfo(
                absorption = "60% absorbed orally. Bioactivated to enalaprilat in liver.",
                distribution = "Crosses placenta; does not cross intact blood-brain barrier.",
                metabolism = "Hepatic ester hydrolysis to active enalaprilat.",
                excretion = "Excreted primarily by kidneys (enalaprilat and unchanged enalapril).",
                bioavailability = "60%",
                proteinBinding = "50% (enalaprilat)",
                volumeOfDistribution = "1.0 L/kg",
                metabolicPathway = "Hepatic Esterase Hydrolysis to Enalaprilat",
                majorEnzymes = emptyList(),
                halfLife = "11 hours (enalaprilat)",
                routeOfElimination = "Renal"
            ),
            specialPopulations = SpecialPopulations(pregnancy = "Contraindicated in pregnancy."),
            monitoring = listOf("Serum potassium", "Serum creatinine", "Blood pressure"),
            patientCounselling = listOf("Report persistent dry cough to doctor.", "Seek emergency care immediately if swelling of lips, tongue, or throat occurs."),
            advantages = listOf("Extensive evidence in clinical trials for mortality reduction in heart failure"),
            limitations = listOf("High incidence of dry cough (~10-15%)"),
            memoryTrick = "-PRIL suffix = ACE Inhibitor for BP & Heart failure (Watch for Dry Cough).",
            references = listOf("CDSCO", "Indian Pharmacopoeia")
        ),

        // 19. Ramipril
        MedicineRecord(
            id = "med-019",
            genericName = "Ramipril",
            saltName = "Ramipril",
            activeIngredients = listOf("Ramipril"),
            brandNames = listOf(
                BrandInfo("Cardace 2.5", "Ramipril", listOf("Ramipril"), "2.5 mg", "Capsule", "Sanofi India", false, "Rs. 95 / 15 caps"),
                BrandInfo("Cardace 5", "Ramipril", listOf("Ramipril"), "5 mg", "Capsule", "Sanofi India", false, "Rs. 150 / 15 caps"),
                BrandInfo("Hopace 5", "Ramipril", listOf("Ramipril"), "5 mg", "Tablet", "Micro Labs", false, "Rs. 80 / 10 tabs")
            ),
            strength = "1.25 mg / 2.5 mg / 5 mg / 10 mg",
            dosageForms = listOf("Capsule", "Tablet"),
            routes = listOf("Oral"),
            pronunciation = "RAM-i-pril",
            romanPronunciation = "Ram-i-pril",
            hinglishPronunciation = "Heart attack aur BP se bachav ki dawai (Ramipril)",
            therapeuticClass = "Antihypertensive & Cardioprotective",
            pharmacologicalClass = "Angiotensin-Converting Enzyme (ACE) Inhibitor",
            drugClass = "Dicarboxylic Acid ACE Inhibitor",
            atcCode = "C09AA05",
            mechanismOfAction = "Prodrug hydrolyzed in liver to ramiprilat, a potent long-acting ACE inhibitor that decreases systemic vascular resistance and aldosterone secretion.",
            indications = listOf("Hypertension", "Heart Failure post-MI", "Cardiovascular Risk Reduction (HOPE Trial)", "Diabetic Nephropathy"),
            uses = listOf("Reducing heart attack and stroke risk in high-risk patients", "Lowering high blood pressure"),
            contraindications = listOf("Pregnancy", "History of angioedema with ACE inhibitors", "Bilateral renal artery stenosis"),
            warnings = listOf("Black Box Warning: Fetal Toxicity. Discontinue immediately when pregnant."),
            precautions = listOf("Dry cough is a frequent class side effect."),
            adverseEffects = listOf("Cough", "Hyperkalemia", "Dizziness", "Hypotension", "Renal impairment"),
            commonSideEffects = listOf("Dry persistent cough", "Dizziness"),
            seriousSideEffects = listOf("Angioedema", "Anaphylactoid reaction"),
            drugInteractions = listOf(
                StructuredInteraction("Potassium Chloride", "Major", "Risk of hyperkalemia.", "Additive potassium retention.", "Avoid concomitant potassium supplements.")
            ),
            foodInteractions = listOf("Can be taken with or without food."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed (50-60%). Hydrolyzed to active ramiprilat.",
                distribution = "Ramiprilat is 56% protein bound.",
                metabolism = "Extensive hepatic esterase cleavage to ramiprilat.",
                excretion = "60% renal excretion, 40% fecal excretion.",
                bioavailability = "28% (ramiprilat)",
                proteinBinding = "56%",
                volumeOfDistribution = "0.7 L/kg",
                metabolicPathway = "Hepatic Esterase Hydrolysis to Ramiprilat",
                majorEnzymes = emptyList(),
                halfLife = "13 to 17 hours (ramiprilat)",
                routeOfElimination = "Renal & Fecal"
            ),
            specialPopulations = SpecialPopulations(pregnancy = "Contraindicated."),
            monitoring = listOf("Renal function and serum potassium"),
            patientCounselling = listOf("Take at the same time every day."),
            advantages = listOf("Proven in HOPE study for high-risk cardiovascular protection"),
            limitations = listOf("Dry cough causing therapy discontinuation"),
            memoryTrick = "RAMI-pril = Renoprotective & Anti-MI ACE Inhibitor.",
            references = listOf("HOPE Study Investigators", "CDSCO")
        ),

        // 20. Furosemide
        MedicineRecord(
            id = "med-020",
            genericName = "Furosemide",
            saltName = "Furosemide / Frusemide",
            activeIngredients = listOf("Furosemide"),
            brandNames = listOf(
                BrandInfo("Lasix 40", "Furosemide", listOf("Furosemide"), "40 mg", "Tablet", "Sanofi India", false, "Rs. 12 / 10 tabs"),
                BrandInfo("Lasix Injection", "Furosemide", listOf("Furosemide"), "20 mg / 2 mL", "Ampoule", "Sanofi India", false, "Rs. 15 / ampoule")
            ),
            strength = "20 mg / 40 mg",
            dosageForms = listOf("Tablet", "Injection"),
            routes = listOf("Oral", "Intravenous", "Intramuscular"),
            pronunciation = "fyoo-ROE-se-mide",
            romanPronunciation = "Fyoo-ro-se-mide",
            hinglishPronunciation = "Sujan aur peshab badhane ki dawai (Lasix / Furosemide)",
            therapeuticClass = "Diuretic & Antihypertensive",
            pharmacologicalClass = "Loop Diuretic",
            drugClass = "Sulfamoyl-Anthranilic Acid Derivative",
            atcCode = "C03CA01",
            mechanismOfAction = "Inhibits Na+/K+/2Cl- cotransporter in the thick ascending limb of Henle's loop, blocking reabsorption of sodium, chloride, and water to induce profound diuresis.",
            indications = listOf("Edema associated with Heart Failure", "Hepatic Cirrhosis Ascites", "Renal Disease Edema", "Acute Pulmonary Edema", "Hypertensive Crisis"),
            uses = listOf("Removing excess body fluid (edema)", "Reducing swelling in legs and lungs in heart failure"),
            contraindications = listOf("Anuria", "Severe sodium and water depletion", "Hepatic coma / encephalopathy", "Sulfonamide allergy (relative)"),
            warnings = listOf("Black Box Warning: Potent diuretic that can lead to profound water and electrolyte depletion."),
            precautions = listOf("Monitor electrolytes (potassium, sodium, magnesium, calcium) frequently."),
            adverseEffects = listOf("Hypokalemia", "Hyponatremia", "Hypomagnesemia", "Hyperuricemia / Gout", "Ototoxicity", "Dehydration"),
            commonSideEffects = listOf("Frequent urination", "Thirst", "Dizziness on standing"),
            seriousSideEffects = listOf("Ototoxicity (deafness, especially with rapid IV administration)", "Severe hypokalemia causing fatal arrhythmia"),
            drugInteractions = listOf(
                StructuredInteraction("Aminoglycosides (Gentamicin)", "Major", "Additive ototoxicity and nephrotoxicity risk.", "Synergistic hair cell damage.", "Avoid combination if possible."),
                StructuredInteraction("Digoxin", "Major", "Hypokalemia induced by furosemide increases digoxin toxicity.", "Potassium depletion.", "Monitor serum potassium; give potassium supplement.")
            ),
            foodInteractions = listOf("Take on empty stomach or with food if stomach upset occurs. Take early in the day to avoid nocturia."),
            adme = ADMEInfo(
                absorption = "Variable oral absorption (10-90%). Peak diuretic effect in 1-2 hours (oral) or 30 mins (IV).",
                distribution = "91-99% bound to plasma albumin.",
                metabolism = "Minimal hepatic glucuronidation (~10-20%).",
                excretion = "60-80% excreted unchanged in urine via active tubular secretion.",
                bioavailability = "50%",
                proteinBinding = "98%",
                volumeOfDistribution = "0.1 to 0.2 L/kg",
                metabolicPathway = "Renal Active Tubular Secretion",
                majorEnzymes = emptyList(),
                halfLife = "1.5 to 2 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Used cautiously in maternal heart failure.",
                geriatric = "High risk of orthostatic hypotension and electrolyte disturbance."
            ),
            monitoring = listOf("Serum electrolytes (K+, Na+, Mg2+)", "Daily body weight", "BUN and creatinine"),
            patientCounselling = listOf("Take last dose before 4 PM to prevent waking up at night to urinate.", "Eat potassium-rich foods (bananas, oranges) if advised."),
            advantages = listOf("Potent diuretic effect even in severe renal impairment (eGFR < 30 mL/min)"),
            limitations = listOf("Short duration of action; high risk of electrolyte depletion"),
            memoryTrick = "LASIX = LAsts SIX hours (Furosemide Loop Diuretic).",
            references = listOf("CDSCO", "Indian Pharmacopoeia")
        ),

        // 21. Spironolactone
        MedicineRecord(
            id = "med-021",
            genericName = "Spironolactone",
            saltName = "Spironolactone",
            activeIngredients = listOf("Spironolactone"),
            brandNames = listOf(
                BrandInfo("Aldactone 25", "Spironolactone", listOf("Spironolactone"), "25 mg", "Tablet", "RPG Life Sciences", false, "Rs. 35 / 15 tabs"),
                BrandInfo("Aldactone 50", "Spironolactone", listOf("Spironolactone"), "50 mg", "Tablet", "RPG Life Sciences", false, "Rs. 65 / 15 tabs"),
                BrandInfo("Lasilactone", "Furosemide + Spironolactone", listOf("Furosemide", "Spironolactone"), "20 mg + 50 mg", "Tablet", "Sanofi India", true, "Rs. 45 / 10 tabs")
            ),
            strength = "25 mg / 50 mg / 100 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "speer-oh-no-LAK-tone",
            romanPronunciation = "Speer-o-no-lak-tone",
            hinglishPronunciation = "Sujan aur potassium bachane wali peshab ki dawai (Spironolactone)",
            therapeuticClass = "Diuretic & Antihypertensive",
            pharmacologicalClass = "Potassium-Sparing Diuretic / Aldosterone Antagonist",
            drugClass = "Mineralocorticoid Receptor Antagonist (MRA)",
            atcCode = "C03DA01",
            mechanismOfAction = "Competitively blocks aldosterone receptors in the late distal tubule and collecting duct, decreasing sodium-water reabsorption while sparing potassium and hydrogen ions.",
            indications = listOf("Heart Failure (NYHA II-IV)", "Hepatic Cirrhosis with Ascites", "Essential Hypertension", "Primary Hyperaldosteronism"),
            uses = listOf("Reducing mortality in severe heart failure", "Managing abdominal fluid swelling in liver disease"),
            contraindications = listOf("Hyperkalemia (K+ > 5.0 mEq/L)", "Severe renal impairment (eGFR < 30 mL/min)", "Addison's disease"),
            warnings = listOf("Black Box Warning: Tumorigenic in animal studies; avoid unnecessary use.", "Risk of severe hyperkalemia."),
            precautions = listOf("Gynecomastia and breast pain occur due to anti-androgenic effects."),
            adverseEffects = listOf("Hyperkalemia", "Gynecomastia (male breast enlargement)", "Menstrual irregularities", "Dizziness", "GI distress"),
            commonSideEffects = listOf("Breast tenderness/enlargement in men", "Frequent urination"),
            seriousSideEffects = listOf("Fatal hyperkalemia", "Severe cardiac arrhythmia"),
            drugInteractions = listOf(
                StructuredInteraction("ACE Inhibitors / ARBs", "Major", "Synergistic hyperkalemia risk.", "Combined inhibition of aldosterone axis.", "Monitor serum potassium closely."),
                StructuredInteraction("Potassium Supplements", "Major", "Severe life-threatening hyperkalemia.", "Additive potassium load.", "Contraindicated.")
            ),
            foodInteractions = listOf("Food increases bioavailability (~100% absorption increase). Take consistently with food."),
            adme = ADMEInfo(
                absorption = "Well absorbed. Food significantly enhances oral bioavailability.",
                distribution = "Metabolites highly protein bound (>90%).",
                metabolism = "Rapidly and extensively metabolized to active metabolites (canrenone and 7-alpha-thiomethylspironolactone).",
                excretion = "Metabolites excreted in urine (47-57%) and bile/feces (35-41%).",
                bioavailability = "90% (with food)",
                proteinBinding = "90%",
                volumeOfDistribution = "0.05 L/kg",
                metabolicPathway = "Hepatic Bioactivation to Canrenone",
                majorEnzymes = listOf("CYP3A4"),
                halfLife = "1.4 hours (parent), 16.5 hours (canrenone metabolite)",
                routeOfElimination = "Renal & Biliary"
            ),
            specialPopulations = SpecialPopulations(pregnancy = "Category C. Avoid unless essential."),
            monitoring = listOf("Serum potassium at 1 week, 1 month, and periodically", "Serum creatinine"),
            patientCounselling = listOf("Avoid potassium-rich salt substitutes.", "Report breast tenderness or irregular periods."),
            advantages = listOf("Proven mortality benefit in chronic heart failure (RALES trial)", "Counteracts hypokalemia caused by loop diuretics"),
            limitations = listOf("Anti-androgenic side effects (gynecomastia in men)"),
            memoryTrick = "SPIRO-nolactone = SPARING Potassium, Blocking Aldosterone.",
            references = listOf("RALES Trial Investigators", "CDSCO")
        ),

        // 22. Atorvastatin
        MedicineRecord(
            id = "med-022",
            genericName = "Atorvastatin",
            saltName = "Atorvastatin Calcium",
            activeIngredients = listOf("Atorvastatin"),
            brandNames = listOf(
                BrandInfo("Atorva 10", "Atorvastatin", listOf("Atorvastatin"), "10 mg", "Tablet", "Zydus Healthcare", false, "Rs. 95 / 15 tabs"),
                BrandInfo("Atorlip 10", "Atorvastatin", listOf("Atorvastatin"), "10 mg", "Tablet", "Cipla", false, "Rs. 90 / 15 tabs"),
                BrandInfo("Lipivas 10", "Atorvastatin", listOf("Atorvastatin"), "10 mg", "Tablet", "Sun Pharma", false, "Rs. 100 / 15 tabs")
            ),
            strength = "10 mg / 20 mg / 40 mg / 80 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "a-TOR-va-sta-tin",
            romanPronunciation = "A-tor-va-sta-tin",
            hinglishPronunciation = "Cholesterol aur heart attack se bachav ki dawai (Atorvastatin Statin)",
            therapeuticClass = "Hypolipidemic Agent",
            pharmacologicalClass = "HMG-CoA Reductase Inhibitor",
            drugClass = "Statin",
            atcCode = "C10AA05",
            mechanismOfAction = "Competitively inhibits HMG-CoA reductase, the rate-limiting enzyme in hepatic cholesterol synthesis. Up-regulates cell-surface LDL receptors, enhancing LDL clearance.",
            indications = listOf("Hypercholesterolemia", "Prevention of Cardiovascular Disease", "Post-ACS / Post-PCI Statin Therapy"),
            uses = listOf("Lowering bad cholesterol (LDL) and triglycerides", "Preventing heart attack and stroke"),
            contraindications = listOf("Active liver disease or unexplained elevated transaminases", "Pregnancy and Lactation"),
            warnings = listOf("Risk of myopathy and rhabdomyolysis.", "Risk of immune-mediated necrotizing myopathy (very rare)."),
            precautions = listOf("Perform liver function tests prior to initiating therapy."),
            adverseEffects = listOf("Myalgia (muscle pain)", "Increased ALT/AST", "Nasopharyngitis", "Arthralgia", "Increased HbA1c (minor)"),
            commonSideEffects = listOf("Mild muscle ache", "Headache", "Nausea"),
            seriousSideEffects = listOf("Rhabdomyolysis", "Hepatic failure", "New-onset diabetes mellitus (rare)"),
            drugInteractions = listOf(
                StructuredInteraction("Clarithromycin / Itraconazole", "Major", "Potent CYP3A4 inhibitors increase atorvastatin plasma levels, raising rhabdomyolysis risk.", "CYP3A4 inhibition.", "Lower atorvastatin dose or use rosuvastatin."),
                StructuredInteraction("Gemfibrozil", "Major", "Increases risk of severe myopathy.", "Inhibition of glucuronidation.", "Avoid combination.")
            ),
            foodInteractions = listOf("Avoid large quantities of grapefruit juice (>1.2 L/day). Can be taken anytime with or without food."),
            adme = ADMEInfo(
                absorption = "Rapidly absorbed. Bioavailability is low (~14%) due to presystemic clearance.",
                distribution = ">= 98% bound to plasma proteins. High hepatic extraction.",
                metabolism = "Extensively metabolized by CYP3A4 to ortho- and parahydroxylated metabolites (account for 70% of active inhibitory activity).",
                excretion = "Excreted primarily in bile (>98%). Minimal renal excretion (<2%).",
                bioavailability = "14%",
                proteinBinding = ">= 98%",
                volumeOfDistribution = "381 L",
                metabolicPathway = "Hepatic CYP3A4 Hydroxylation",
                majorEnzymes = listOf("CYP3A4"),
                halfLife = "14 hours (active metabolites inhibitory half-life 20-30 hours)",
                routeOfElimination = "Biliary (Fecal)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Contraindicated (Teratogenic potential in fetal neural membrane synthesis).",
                geriatric = "Standard doses tolerated; monitor for muscle symptoms."
            ),
            monitoring = listOf("Lipid profile at baseline and 4-12 weeks after starting", "Liver enzymes (ALT) baseline", "Creatine kinase (CK) if myalgia occurs"),
            patientCounselling = listOf("Report unexplained muscle pain, tenderness, or dark urine immediately.", "Can be taken anytime of day."),
            advantages = listOf("Long active metabolite half-life permits dosing at any time of day (unlike simvastatin)"),
            limitations = listOf("CYP3A4 metabolism creates drug interaction potential"),
            memoryTrick = "-STATIN suffix = HMG-CoA Reductase Inhibitor for Cholesterol.",
            references = listOf("ACC/AHA Cholesterol Guidelines", "CDSCO Approved Drug List")
        ),

        // 23. Rosuvastatin
        MedicineRecord(
            id = "med-023",
            genericName = "Rosuvastatin",
            saltName = "Rosuvastatin Calcium",
            activeIngredients = listOf("Rosuvastatin"),
            brandNames = listOf(
                BrandInfo("Rosuvas 10", "Rosuvastatin", listOf("Rosuvastatin"), "10 mg", "Tablet", "Sun Pharma", false, "Rs. 180 / 15 tabs"),
                BrandInfo("Rozavel 10", "Rosuvastatin", listOf("Rosuvastatin"), "10 mg", "Tablet", "Sun Pharma", false, "Rs. 175 / 15 tabs"),
                BrandInfo("Crestor 10", "Rosuvastatin", listOf("Rosuvastatin"), "10 mg", "Tablet", "AstraZeneca India", false, "Rs. 240 / 15 tabs")
            ),
            strength = "5 mg / 10 mg / 20 mg / 40 mg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "roe-SOO-va-sta-tin",
            romanPronunciation = "Ro-soo-va-sta-tin",
            hinglishPronunciation = "Cholesterol kam karne ki dawai (Rosuvastatin Statin)",
            therapeuticClass = "Hypolipidemic Agent",
            pharmacologicalClass = "HMG-CoA Reductase Inhibitor",
            drugClass = "High-Potency Statin",
            atcCode = "C10AA07",
            mechanismOfAction = "Potent competitive inhibitor of HMG-CoA reductase. Hydrophilic statin with high hepatic selectivity, significantly reducing LDL-C and increasing HDL-C.",
            indications = listOf("Hypercholesterolemia", "Mixed Dyslipidemia", "Primary Prevention of Cardiovascular Events (JUPITER Trial)"),
            uses = listOf("Most effective lowering of bad cholesterol (LDL)", "Reducing arterial plaque progression"),
            contraindications = listOf("Active liver disease", "Pregnancy and Lactation", "Severe renal impairment (40 mg dose)"),
            warnings = listOf("Myopathy/rhabdomyolysis risk. Higher incidence in Asian populations at maximum dose."),
            precautions = listOf("Start at 5 mg dose in patients of Asian ancestry."),
            adverseEffects = listOf("Myalgia", "Headache", "Abdominal pain", "Asthenia", "Proteinuria (transient at high dose)"),
            commonSideEffects = listOf("Muscle pain", "Headache", "Constipation"),
            seriousSideEffects = listOf("Rhabdomyolysis", "Immune-mediated necrotizing myopathy"),
            drugInteractions = listOf(
                StructuredInteraction("Cyclosporine", "Major", "Increases rosuvastatin exposure 7-fold.", "OATP1B1 transport inhibition.", "Avoid combination or cap dose at 5 mg."),
                StructuredInteraction("Antacids (Al/Mg)", "Moderate", "Decreases rosuvastatin absorption.", "Reduced dissolution.", "Take antacids 2 hours after rosuvastatin.")
            ),
            foodInteractions = listOf("Can be taken with or without food at any time of day."),
            adme = ADMEInfo(
                absorption = "Peak plasma concentration in 3-5 hours. Absolute bioavailability ~20%.",
                distribution = "Hydrophilic; selective uptake into hepatocytes via OATP1B1.",
                metabolism = "Limited hepatic metabolism (~10%) mainly via CYP2C9.",
                excretion = "90% excreted unchanged in feces (via biliary excretion). 10% in urine.",
                bioavailability = "20%",
                proteinBinding = "88%",
                volumeOfDistribution = "134 L",
                metabolicPathway = "Minimal Hepatic CYP2C9 Metabolism",
                majorEnzymes = listOf("CYP2C9"),
                halfLife = "19 hours",
                routeOfElimination = "Biliary (Fecal)"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Contraindicated.",
                pediatric = "Approved for familial hypercholesterolemia in pediatric patients."
            ),
            monitoring = listOf("Lipid panel", "Liver function tests at baseline", "Renal function for 40 mg dose"),
            patientCounselling = listOf("Report dark urine or severe muscle weakness promptly.", "Take once daily anytime."),
            advantages = listOf("Highest LDL-lowering potency per mg among statins", "Minimal CYP3A4 interaction compared to atorvastatin"),
            limitations = listOf("Higher risk of myopathy in Asian ethnicity requiring lower starting dose"),
            memoryTrick = "ROSU-vastatin = ROBUST LDL reduction with minimal CYP3A4 interactions.",
            references = listOf("JUPITER Trial Results", "CDSCO Approved Drug List")
        ),

        // 24. Levothyroxine
        MedicineRecord(
            id = "med-024",
            genericName = "Levothyroxine",
            saltName = "Levothyroxine Sodium (T4)",
            activeIngredients = listOf("Levothyroxine"),
            brandNames = listOf(
                BrandInfo("Thyronorm 50", "Levothyroxine", listOf("Levothyroxine"), "50 mcg", "Tablet", "Abbott India", false, "Rs. 130 / 100 tabs"),
                BrandInfo("Eltroxin 50", "Levothyroxine", listOf("Levothyroxine"), "50 mcg", "Tablet", "GSK India", false, "Rs. 125 / 100 tabs"),
                BrandInfo("Thyroup 25", "Levothyroxine", listOf("Levothyroxine"), "25 mcg", "Tablet", "Mankind", false, "Rs. 110 / 100 tabs")
            ),
            strength = "12.5 mcg / 25 mcg / 50 mcg / 75 mcg / 100 mcg / 125 mcg",
            dosageForms = listOf("Tablet"),
            routes = listOf("Oral"),
            pronunciation = "lee-voe-thye-ROK-seen",
            romanPronunciation = "Lee-vo-thy-rok-seen",
            hinglishPronunciation = "Thyroid hormone ki dawai (Levothyroxine T4)",
            therapeuticClass = "Thyroid Hormone",
            pharmacologicalClass = "Synthetic T4 Hormone",
            drugClass = "Thyroid Replacement Agent",
            atcCode = "H03AA01",
            mechanismOfAction = "Synthetic form of thyroxine (T4) converted peripherally to active triiodothyronine (T3). Binds to thyroid receptor proteins in cell nucleus, regulating gene expression and metabolic rate.",
            indications = listOf("Hypothyroidism (Primary, Secondary, Tertiary)", "Congenital Hypothyroidism", "TSH Suppression in Thyroid Cancer"),
            uses = listOf("Replacing deficient thyroid hormone", "Restoring normal metabolism, energy, and weight control"),
            contraindications = listOf("Thyrotoxicosis", "Acute Myocardial Infarction", "Uncorrected adrenal insufficiency"),
            warnings = listOf("Black Box Warning: Not for weight loss or obesity treatment; toxic in euthyroid patients."),
            precautions = listOf("Narrow therapeutic index drug; maintain same brand/formulation if possible."),
            adverseEffects = listOf("Tachycardia", "Palpitations", "Weight loss", "Insomnia", "Tremor", "Heat intolerance", "Headache"),
            commonSideEffects = listOf("Palpitations (if dose too high)", "Nervousness", "Insomnia"),
            seriousSideEffects = listOf("Cardiac arrhythmia", "Angina in patients with CAD", "Osteoporosis (from long-term over-suppression)"),
            drugInteractions = listOf(
                StructuredInteraction("Calcium / Iron / Antacids", "Major", "Chelates levothyroxine in gut, drastically reducing absorption.", "Insoluble binding.", "Separate levothyroxine and calcium/iron by 4 hours."),
                StructuredInteraction("Warfarin", "Major", "Increases catabolism of clotting factors, enhancing anticoagulation.", "Accelerated factor clearance.", "Monitor INR; decrease warfarin dose.")
            ),
            foodInteractions = listOf("Take on an empty stomach with plain water at least 30-60 minutes before breakfast."),
            adme = ADMEInfo(
                absorption = "Absorbed in jejunum and ileum (40-80%). Bioavailability significantly reduced by food and minerals.",
                distribution = "> 99% bound to plasma proteins (thyroxine-binding globulin [TBG], transthyretin, albumin).",
                metabolism = "Deiodinated in liver and peripheral tissues to active T3 and reverse T3.",
                excretion = "Renal excretion of metabolites and fecal excretion.",
                bioavailability = "40% to 80%",
                proteinBinding = "> 99%",
                volumeOfDistribution = "11.6 L",
                metabolicPathway = "Peripheral Deiodination to T3",
                majorEnzymes = listOf("Deiodinases (DIO1, DIO2)"),
                halfLife = "6 to 7 days (euthyroid), 9-10 days (hypothyroid)",
                routeOfElimination = "Urinary & Fecal"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category A. Levothyroxine requirement increases in pregnancy (~30-50% dose increase needed).",
                pediatric = "Critical for brain development in infant hypothyroidism; treat immediately."
            ),
            monitoring = listOf("Serum TSH levels 6-8 weeks after starting or changing dose", "Free T4 levels"),
            patientCounselling = listOf("Take first thing in the morning with water 30-60 minutes before tea/coffee/breakfast.", "Keep 4 hours gap before taking calcium or iron tablets."),
            advantages = listOf("Long 7-day half-life ensures smooth plasma levels with once-daily dosing"),
            limitations = listOf("Requires strict administration discipline (fasting status)"),
            memoryTrick = "LEVO-thyroxine = T4 LEVO replacement taken FIRST thing on EMPTY stomach.",
            references = listOf("American Thyroid Association (ATA) Guidelines", "CDSCO Approved List")
        ),

        // 25. Salbutamol / Albuterol
        MedicineRecord(
            id = "med-025",
            genericName = "Salbutamol",
            saltName = "Salbutamol Sulfate / Albuterol",
            activeIngredients = listOf("Salbutamol"),
            brandNames = listOf(
                BrandInfo("Asthalin Inhaler", "Salbutamol", listOf("Salbutamol"), "100 mcg/puff", "MDI Inhaler", "Cipla", false, "Rs. 160 / 200 puffs"),
                BrandInfo("Asthalin Respules", "Salbutamol", listOf("Salbutamol"), "2.5 mg/2.5 mL", "Nebulizer Solution", "Cipla", false, "Rs. 12 / respule"),
                BrandInfo("Asthalin 4", "Salbutamol", listOf("Salbutamol"), "4 mg", "Tablet", "Cipla", false, "Rs. 10 / 30 tabs")
            ),
            strength = "100 mcg/puff (Inhaler) / 2 mg / 4 mg (Tablet)",
            dosageForms = listOf("MDI Inhaler", "Rotacaps", "Nebulizer Solution", "Syrup", "Tablet"),
            routes = listOf("Inhalation", "Oral"),
            pronunciation = "sal-BYOO-ta-mol",
            romanPronunciation = "Sal-byoo-ta-mol",
            hinglishPronunciation = "Asthma aur saas phoolne ka inhaler (Asthalin / Salbutamol)",
            therapeuticClass = "Bronchodilator",
            pharmacologicalClass = "Short-Acting Beta-2 Adrenergic Agonist (SABA)",
            drugClass = "Beta-2 Agonist",
            atcCode = "R03AC02",
            mechanismOfAction = "Selectively stimulates beta-2 adrenergic receptors in bronchial smooth muscle, activating adenylate cyclase to increase intracellular cAMP, causing bronchial smooth muscle relaxation.",
            indications = listOf("Acute Bronchospasm in Asthma", "COPD Exacerbation", "Exercise-Induced Bronchospasm"),
            uses = listOf("Quick-relief rescue inhaler for sudden asthma breathlessness", "Opening narrowed airways"),
            contraindications = listOf("Hypersensitivity to salbutamol", "Threatened abortion during 1st/2nd trimester (if IV used)"),
            warnings = listOf("Overuse indicates poorly controlled asthma requiring anti-inflammatory inhaled corticosteroids."),
            precautions = listOf("May cause transient hypokalemia and hyperglycemia at high nebulized doses."),
            adverseEffects = listOf("Fine tremor (especially hands)", "Tachycardia", "Palpitations", "Headache", "Hypokalemia"),
            commonSideEffects = listOf("Hand tremor", "Fast heart rate", "Nervousness"),
            seriousSideEffects = listOf("Paradoxical bronchospasm", "Severe hypokalemia", "Cardiac arrhythmia"),
            drugInteractions = listOf(
                StructuredInteraction("Non-Selective Beta Blockers (Propranolol)", "Major", "Antagonizes bronchodilator effect of salbutamol.", "Competitive beta receptor blockade.", "Avoid non-selective beta blockers in asthmatics.")
            ),
            foodInteractions = listOf("No specific food interactions for inhaled form."),
            adme = ADMEInfo(
                absorption = "Inhaled dose acts locally in lungs within 5 mins. Swallowed portion absorbed from GI tract.",
                distribution = "Low protein binding (10%). Local action in bronchial tree.",
                metabolism = "Hepatic metabolism to inactive 4'-O-sulfate conjugate.",
                excretion = "Excreted in urine within 72 hours (80% as metabolites and unchanged drug).",
                bioavailability = "Local airway action; systemic bioavailability of swallowed portion ~50%.",
                proteinBinding = "10%",
                volumeOfDistribution = "156 L",
                metabolicPathway = "Hepatic Sulfation",
                majorEnzymes = emptyList(),
                halfLife = "3.8 to 5 hours",
                routeOfElimination = "Urinary"
            ),
            specialPopulations = SpecialPopulations(
                pregnancy = "Category C. Inhaled rescue medication safe and necessary in acute asthma."
            ),
            monitoring = listOf("Rescue inhaler usage frequency", "Serum potassium in severe exacerbations"),
            patientCounselling = listOf("Always carry rescue inhaler with you.", "Rinse mouth with water after inhalation if using combination products."),
            advantages = listOf("Rapid onset of bronchodilation (3-5 minutes)", "Essential life-saving rescue inhaler"),
            limitations = listOf("Short duration of action (4-6 hours); does not treat underlying bronchial inflammation"),
            memoryTrick = "SABA = Short-Acting Beta Agonist for Sudden Asthma Attack.",
            references = listOf("GINA Asthma Guidelines", "CDSCO Approved Drug List")
        )
    )
}
