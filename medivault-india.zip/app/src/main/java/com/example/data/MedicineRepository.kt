package com.example.data

import com.example.model.*

object MedicineRepository {

    val allMedicines: List<MedicineRecord> by lazy {
        DemoMedicinesPart1.list + DemoMedicinesPart2.list + DemoMedicinesPart3.list
    }

    val suffixPatterns: List<SuffixPattern> = listOf(
        SuffixPattern(
            id = "suf-01",
            pattern = "-cillin",
            drugClass = "Aminopenicillin / Beta-Lactam Antibiotic",
            therapeuticCategory = "Antibacterial",
            description = "Binds penicillin-binding proteins to destroy bacterial cell wall peptidoglycan.",
            memoryTrick = "-CILLIN = Cell Wall Inhibition in Bacteria",
            examples = listOf("Amoxicillin", "Ampicillin", "Piperacillin")
        ),
        SuffixPattern(
            id = "suf-02",
            pattern = "-floxacin",
            drugClass = "Fluoroquinolone Antibiotic",
            therapeuticCategory = "Antibacterial",
            description = "Inhibits bacterial DNA gyrase and topoisomerase IV preventing replication.",
            memoryTrick = "-FLOXACIN = FLOW of DNA replication blocked",
            examples = listOf("Ciprofloxacin", "Levofloxacin", "Ofloxacin")
        ),
        SuffixPattern(
            id = "suf-03",
            pattern = "-setron",
            drugClass = "5-HT3 Serotonin Antagonist",
            therapeuticCategory = "Antiemetic",
            description = "Blocks serotonin 5-HT3 receptors in CTZ and gut to prevent nausea and vomiting.",
            memoryTrick = "-SETRON = Serotonin Eradicator for Stopping Vomiting",
            examples = listOf("Ondansetron", "Granisetron", "Palonosetron")
        ),
        SuffixPattern(
            id = "suf-04",
            pattern = "-gliflozin",
            drugClass = "SGLT2 Inhibitor",
            therapeuticCategory = "Antidiabetic & Cardiorenal",
            description = "Inhibits renal SGLT2 cotransporters, causing glucose excretion via urine.",
            memoryTrick = "-GLIFLOZIN = Glucose FLOWS out in urine",
            examples = listOf("Dapagliflozin", "Empagliflozin", "Canagliflozin")
        ),
        SuffixPattern(
            id = "suf-05",
            pattern = "-gliptin",
            drugClass = "DPP-4 Inhibitor",
            therapeuticCategory = "Antidiabetic",
            description = "Blocks DPP-4 enzyme to prolong active GLP-1/GIP incretin hormones.",
            memoryTrick = "-GLIPTIN = Incretin Protection for Glucose Control",
            examples = listOf("Sitagliptin", "Vildagliptin", "Linagliptin")
        ),
        SuffixPattern(
            id = "suf-06",
            pattern = "-prazole",
            drugClass = "Proton Pump Inhibitor (PPI)",
            therapeuticCategory = "Gastroprotective",
            description = "Irreversibly inhibits parietal cell H+/K+ ATPase pump to block acid production.",
            memoryTrick = "-PRAZOLE = Pump Reduction Acid Zero Level",
            examples = listOf("Omeprazole", "Pantoprazole", "Rabeprazole")
        ),
        SuffixPattern(
            id = "suf-07",
            pattern = "-tidine",
            drugClass = "Histamine H2-Receptor Blocker",
            therapeuticCategory = "Gastroprotective",
            description = "Competitively blocks histamine H2 receptors on gastric parietal cells.",
            memoryTrick = "-TIDINE = Two (H2) Blocker for Acid Relief",
            examples = listOf("Ranitidine", "Famotidine", "Cimetidine")
        ),
        SuffixPattern(
            id = "suf-08",
            pattern = "-sartan",
            drugClass = "Angiotensin II Receptor Blocker (ARB)",
            therapeuticCategory = "Antihypertensive",
            description = "Blocks AT1 angiotensin receptors to promote vasodilation and lower blood pressure.",
            memoryTrick = "-SARTAN = Systemic Arterial Relaxer",
            examples = listOf("Telmisartan", "Losartan", "Valsartan")
        ),
        SuffixPattern(
            id = "suf-09",
            pattern = "-olol",
            drugClass = "Beta-Adrenergic Blocker",
            therapeuticCategory = "Antihypertensive & Antiarrhythmic",
            description = "Inhibits beta-1 adrenergic receptors, slowing heart rate and lowering blood pressure.",
            memoryTrick = "-OLOL = Slows Heart Rate & Lowers Output",
            examples = listOf("Atenolol", "Metoprolol", "Propranolol")
        )
    )

    val medicalTerms: List<MedicalTerm> = listOf(
        MedicalTerm(
            id = "term-01",
            term = "Anaphylaxis",
            category = "Immune Response",
            phonetic = "an-ah-fih-LAK-sis",
            explanations = TermExplanations(
                simple = "A severe, life-threatening allergic reaction that needs immediate emergency medical treatment.",
                hinglish = "Janleva allergy reaction jisme saas lene me takleef aur blood pressure gir jata hai.",
                student = "Acute IgE-mediated type I hypersensitivity involving systemic mast cell degranulation, airway compromise, and vascular collapse.",
                medical = "Systemic release of histamine and leukotrienes causing bronchospasm, laryngeal edema, capillary leak, and severe hypotension requiring epinephrine."
            ),
            relatedMedicines = listOf("Paracetamol", "Amoxicillin", "Cetirizine")
        ),
        MedicalTerm(
            id = "term-02",
            term = "Pyrexia",
            category = "Symptom",
            phonetic = "pie-REK-see-ah",
            explanations = TermExplanations(
                simple = "High body temperature or fever caused by illness.",
                hinglish = "Shareer ka tapman badhna ya bukhar aana.",
                student = "Elevation of central body temperature above normal daily variation due to hypothalamic set-point reset by pyrogens.",
                medical = "Pyrogen-induced prostaglandin E2 (PGE2) synthesis in preoptic hypothalamus resetting thermoregulatory set-point."
            ),
            relatedMedicines = listOf("Paracetamol", "Ibuprofen")
        ),
        MedicalTerm(
            id = "term-03",
            term = "Gastroprokinetic",
            category = "Pharmacology",
            phonetic = "gas-troe-proe-ki-NET-ik",
            explanations = TermExplanations(
                simple = "A medicine that helps food move faster through the stomach and intestines.",
                hinglish = "Pate me khana aage badhane wali aur bharepan ko kam karne wali dawai.",
                student = "An agent that enhances gastrointestinal motility by increasing smooth muscle contractions in upper GI tract.",
                medical = "D2 receptor antagonist or 5-HT4 agonist enhancing acetylcholine release at myenteric plexus to improve gastric emptying."
            ),
            relatedMedicines = listOf("Domperidone", "Metoclopramide")
        ),
        MedicalTerm(
            id = "term-04",
            term = "Glucosuria",
            category = "Nephrology / Metabolism",
            phonetic = "gloo-koe-SOO-ree-ah",
            explanations = TermExplanations(
                simple = "Excretion of sugar (glucose) in the urine.",
                hinglish = "Peshab ke zariye sugar ka bahar nikalna.",
                student = "Excretion of glucose into urine when blood glucose exceeds renal threshold (~180 mg/dL) or SGLT2 is inhibited.",
                medical = "Exceeding proximal tubule tubular maximum for glucose reabsorption or pharmacological block of SGLT2 cotransporter."
            ),
            relatedMedicines = listOf("Dapagliflozin")
        ),
        MedicalTerm(
            id = "term-05",
            term = "Dyspepsia",
            category = "Gastroenterology",
            phonetic = "dis-PEP-see-ah",
            explanations = TermExplanations(
                simple = "Indigestion, stomach discomfort, or burning feeling after eating.",
                hinglish = "Pate me badhazmi, tezaabiyat ya khana na pachne ka ahsaas.",
                student = "Persistent or recurrent pain/discomfort centered in upper abdomen, often associated with bloating or early satiety.",
                medical = "Impaired gastric accommodation, visceral hypersensitivity, or acid-peptic irritation of upper gastrointestinal mucosa."
            ),
            relatedMedicines = listOf("Omeprazole", "Ranitidine", "Domperidone")
        )
    )

    fun search(query: String): List<MedicineRecord> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allMedicines
        return allMedicines.filter { med ->
            med.genericName.lowercase().contains(q) ||
            med.saltName.lowercase().contains(q) ||
            med.therapeuticClass.lowercase().contains(q) ||
            med.pharmacologicalClass.lowercase().contains(q) ||
            med.drugClass.lowercase().contains(q) ||
            med.activeIngredients.any { it.lowercase().contains(q) } ||
            med.brandNames.any { it.brandName.lowercase().contains(q) || it.manufacturer.lowercase().contains(q) } ||
            med.indications.any { it.lowercase().contains(q) } ||
            med.uses.any { it.lowercase().contains(q) }
        }
    }

    fun getAllBrands(): List<Pair<BrandInfo, MedicineRecord>> {
        val result = mutableListOf<Pair<BrandInfo, MedicineRecord>>()
        allMedicines.forEach { med ->
            med.brandNames.forEach { brand ->
                result.add(Pair(brand, med))
            }
        }
        return result
    }

    fun findInteractions(medIds: List<String>): List<Triple<MedicineRecord, MedicineRecord, StructuredInteraction>> {
        val selectedMeds = allMedicines.filter { it.id in medIds }
        val matches = mutableListOf<Triple<MedicineRecord, MedicineRecord, StructuredInteraction>>()

        for (med in selectedMeds) {
            for (interaction in med.drugInteractions) {
                val targetMed = selectedMeds.find { other ->
                    other.genericName.contains(interaction.medicineName, ignoreCase = true) ||
                    other.activeIngredients.any { it.contains(interaction.medicineName, ignoreCase = true) }
                }
                if (targetMed != null && targetMed.id != med.id) {
                    matches.add(Triple(med, targetMed, interaction))
                }
            }
        }
        return matches.distinctBy { Pair(it.first.id, it.second.id) }
    }
}
