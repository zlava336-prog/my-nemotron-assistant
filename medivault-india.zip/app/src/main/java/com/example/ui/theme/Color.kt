package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Brand Palette
val Emerald600 = Color(0xFF059669)
val Emerald700 = Color(0xFF047857)
val Emerald500 = Color(0xFF10B981)
val Emerald200 = Color(0xFFA7F3D0)
val Emerald100 = Color(0xFFD1FAE5)
val Emerald50 = Color(0xFFECFDF5)

// Slate Neutral Palette
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val BgSlate = Color(0xFFF0F2F5)

// Category Accent Palettes
val Blue700 = Color(0xFF1D4ED8)
val Blue100 = Color(0xFFDBEAFE)
val Blue50 = Color(0xFFEFF6FF)

val Amber700 = Color(0xFFB45309)
val Amber100 = Color(0xFFFEF3C7)
val Amber50 = Color(0xFFFFFBEB)

val Rose700 = Color(0xFFBE123C)
val Rose100 = Color(0xFFFFE4E6)
val Rose50 = Color(0xFFFFF1F2)

val Purple700 = Color(0xFF7E22CE)
val Purple100 = Color(0xFFF3E8FF)
val Purple50 = Color(0xFFFAF5FF)

val Cyan700 = Color(0xFF0E7490)
val Cyan100 = Color(0xFFCFFAFE)
val Cyan50 = Color(0xFFECFEFF)

val Indigo700 = Color(0xFF4338CA)
val Indigo100 = Color(0xFFE0E7FF)
val Indigo50 = Color(0xFFEEF2FF)

