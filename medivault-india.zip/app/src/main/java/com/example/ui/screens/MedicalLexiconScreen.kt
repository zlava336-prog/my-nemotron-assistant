package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRepository
import com.example.model.ExplanationMode
import com.example.ui.theme.*

@Composable
fun MedicalLexiconScreen(
    selectedMode: ExplanationMode,
    onModeSelect: (ExplanationMode) -> Unit
) {
    val terms = remember { MedicineRepository.medicalTerms }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("medical_lexicon_screen")
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Indigo50)
                .border(1.dp, Indigo100, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Book, contentDescription = null, tint = Indigo700, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MEDICAL LEXICON & TERMINOLOGY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = Indigo700
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Understand clinical terms with 4 explanation depth levels.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mode Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ExplanationMode.values().forEach { mode ->
                val isSelected = mode == selectedMode
                FilterChip(
                    selected = isSelected,
                    onClick = { onModeSelect(mode) },
                    label = {
                        Text(
                            text = mode.name,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Indigo100,
                        selectedLabelColor = Indigo700,
                        containerColor = Color.White,
                        labelColor = Slate700
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(terms) { term ->
                val explanationText = when (selectedMode) {
                    ExplanationMode.SIMPLE -> term.explanations.simple
                    ExplanationMode.HINGLISH -> term.explanations.hinglish
                    ExplanationMode.STUDENT -> term.explanations.student
                    ExplanationMode.MEDICAL -> term.explanations.medical
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White)
                        .border(1.dp, Slate200, RoundedCornerShape(20.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = term.term,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                color = Slate900
                            )
                            Text(
                                text = term.phonetic,
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "Category: ${term.category}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Indigo700
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = explanationText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Slate800
                        )

                        if (term.relatedMedicines.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Related Drugs: ${term.relatedMedicines.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate600
                            )
                        }
                    }
                }
            }
        }
    }
}
