package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRepository
import com.example.model.MedicineRecord
import com.example.ui.theme.*

@Composable
fun AdmeExplorerScreen(
    onMedicineClick: (MedicineRecord) -> Unit
) {
    val allMeds = remember { MedicineRepository.allMedicines }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("adme_explorer_screen")
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Purple50)
                .border(1.dp, Purple100, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Biotech, contentDescription = null, tint = Purple700, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ADME & PHARMACOKINETICS EXPLORER",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = Purple700
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Absorption, Distribution, CYP Enzyme Metabolism & Excretion parameters.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(allMeds) { med ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White)
                        .border(1.dp, Slate200, RoundedCornerShape(20.dp))
                        .clickable { onMedicineClick(med) }
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = med.genericName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                color = Slate900
                            )
                            Text(
                                text = "t½: ${med.adme.halfLife}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Purple700
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Metabolism: ${med.adme.metabolism}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate700
                        )

                        if (med.adme.majorEnzymes.isNotEmpty()) {
                            Text(
                                text = "CYP Enzymes: ${med.adme.majorEnzymes.joinToString(", ")}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Slate600
                            )
                        }

                        Text(
                            text = "Bioavailability: ${med.adme.bioavailability} • Excretion: ${med.adme.excretion}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500
                        )
                    }
                }
            }
        }
    }
}
