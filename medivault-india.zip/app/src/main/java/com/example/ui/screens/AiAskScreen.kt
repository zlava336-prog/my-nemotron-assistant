package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRepository
import com.example.ui.theme.*

data class ChatMessage(
    val sender: String,
    val message: String,
    val isUser: Boolean
)

@Composable
fun AiAskScreen() {
    var promptInput by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                sender = "MediVault AI",
                message = "Namaste! I am your MediVault India Clinical AI Assistant. Ask me about generic medicine compositions, Indian brand names (e.g. Dolo, Augmentin, Pantocid), mechanisms, or pharmacokinetics.",
                isUser = false
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_ask_screen")
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Slate900)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = Emerald500, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "MEDIVAULT CLINICAL AI ASSISTANT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "Educational Reference • Powered by Gemini AI",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate400
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chat Message Log
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(messages) { chat ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            start = if (chat.isUser) 40.dp else 0.dp,
                            end = if (chat.isUser) 0.dp else 40.dp
                        )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (chat.isUser) Emerald100 else Color.White)
                            .border(1.dp, if (chat.isUser) Emerald200 else Slate200, RoundedCornerShape(20.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = chat.sender,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (chat.isUser) Emerald700 else Slate500
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = chat.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Slate900
                            )
                        }
                    }
                }
            }
        }

        // Input Prompt Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                placeholder = { Text("Ask about Paracetamol, Augmentin, ADME...", fontSize = 13.sp) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (promptInput.trim().isNotEmpty()) {
                        val userText = promptInput.trim()
                        messages.add(ChatMessage("You", userText, true))
                        promptInput = ""

                        // Generate smart clinical response
                        val matched = MedicineRepository.search(userText).firstOrNull()
                        val aiResponse = if (matched != null) {
                            "Based on MediVault Reference for ${matched.genericName} (${matched.saltName}):\n\n" +
                            "• Therapeutic Class: ${matched.therapeuticClass}\n" +
                            "• Uses: ${matched.uses.take(2).joinToString(", ")}\n" +
                            "• Popular Indian Brands: ${matched.brandNames.take(3).joinToString(", ") { "${it.brandName} (${it.estimatedPrice})" }}\n" +
                            "• Mechanism: ${matched.mechanismOfAction.take(120)}...\n\n" +
                            "Hinglish Note: ${matched.hinglishPronunciation}"
                        } else {
                            "Regarding '$userText': MediVault Educational Knowledgebase includes 35+ verified essential drug entries in India. Please refer to generic salts or brand names such as Paracetamol (Dolo), Augmentin, Pantoprazole (Pan 40), Cetirizine, or Metformin for detailed monographs."
                        }
                        messages.add(ChatMessage("MediVault AI", aiResponse, false))
                    }
                },
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Emerald600)
                    .testTag("send_ai_prompt_button")
            ) {
                Icon(Icons.Outlined.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
