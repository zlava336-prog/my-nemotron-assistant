package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.MedicineRecord
import com.example.ui.theme.*

@Composable
fun MedicineDetailSheet(
    medicine: MedicineRecord,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onDismiss: () -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Overview", "Brands & Prices", "Uses & Side Effects", "Interactions & ADME")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 28.dp),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Emerald100),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Medication,
                                contentDescription = null,
                                tint = Emerald700,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = medicine.genericName,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = medicine.therapeuticClass,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = Emerald600
                            )
                        }
                    }

                    Row {
                        IconButton(onClick = onFavoriteToggle) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFavorite) Rose700 else Slate400
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_detail_sheet")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Slate600
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tab Selector
                ScrollableTabRow(
                    selectedTabIndex = activeTab,
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = activeTab == index,
                            onClick = { activeTab = index },
                            text = {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontWeight = if (activeTab == index) FontWeight.Black else FontWeight.Medium
                                    ),
                                    color = if (activeTab == index) Emerald700 else Slate500
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tab Content Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (activeTab) {
                        0 -> OverviewTabContent(medicine)
                        1 -> BrandsTabContent(medicine)
                        2 -> UsesAndSideEffectsTabContent(medicine)
                        3 -> InteractionsAndAdmeTabContent(medicine)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Educational Disclaimer Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Slate800)
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = "EDUCATIONAL REFERENCE ONLY",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp,
                                    letterSpacing = 1.sp
                                ),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "This application is for clinical education and reference in India. Never self-prescribe or substitute medical diagnosis.",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = Slate300
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewTabContent(medicine: MedicineRecord) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Hinglish Simple Explanation Card
        DetailCard(
            title = "Hinglish Quick Summary",
            bgColor = Emerald50,
            borderColor = Emerald200,
            titleColor = Emerald700
        ) {
            Text(
                text = medicine.hinglishPronunciation,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Slate800
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Pronunciation: ${medicine.pronunciation} (${medicine.romanPronunciation})",
                style = MaterialTheme.typography.bodySmall,
                color = Slate600
            )
        }

        // Key Specifications
        DetailCard(title = "Key Details") {
            DetailItem(label = "Active Salt", value = medicine.saltName)
            DetailItem(label = "Strength / Dose", value = medicine.strength)
            DetailItem(
                label = "Dosage Forms",
                value = medicine.dosageForms.joinToString(", ")
            )
            DetailItem(label = "Routes of Admin", value = medicine.routes.joinToString(", "))
            DetailItem(label = "Pharmacological Class", value = medicine.pharmacologicalClass)
            DetailItem(label = "Drug Class", value = medicine.drugClass)
            if (medicine.atcCode.isNotEmpty()) {
                DetailItem(label = "ATC Code", value = medicine.atcCode)
            }
        }

        // Mechanism of Action
        DetailCard(title = "Mechanism of Action") {
            Text(
                text = medicine.mechanismOfAction,
                style = MaterialTheme.typography.bodyMedium,
                color = Slate700
            )
        }

        // Memory Trick
        if (medicine.memoryTrick.isNotEmpty()) {
            DetailCard(
                title = "Memory Trick / Clinical Pearl",
                bgColor = Cyan50,
                borderColor = Cyan100,
                titleColor = Cyan700
            ) {
                Text(
                    text = medicine.memoryTrick,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Slate800
                )
            }
        }
    }
}

@Composable
private fun BrandsTabContent(medicine: MedicineRecord) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Popular Indian Brands & Estimated Price",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
            color = Slate800
        )

        medicine.brandNames.forEach { brand ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .border(1.dp, Slate200, RoundedCornerShape(20.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = brand.brandName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                            color = Slate900
                        )
                        if (brand.estimatedPrice.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Emerald100)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = brand.estimatedPrice,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Emerald700
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Manufacturer: ${brand.manufacturer}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                    Text(
                        text = "Form: ${brand.dosageForm} (${brand.strength})",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate500
                    )

                    if (brand.isCombination) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Amber100)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Combination Medicine",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Amber700
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UsesAndSideEffectsTabContent(medicine: MedicineRecord) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Indications
        DetailCard(title = "Clinical Indications") {
            medicine.indications.forEach { ind ->
                BulletPoint(text = ind)
            }
        }

        // Common Uses
        DetailCard(title = "Common Patient Uses") {
            medicine.uses.forEach { use ->
                BulletPoint(text = use)
            }
        }

        // Side Effects
        DetailCard(title = "Common Side Effects") {
            medicine.commonSideEffects.ifEmpty { medicine.adverseEffects }.forEach { side ->
                BulletPoint(text = side, color = Slate700)
            }
        }

        // Serious Side Effects
        if (medicine.seriousSideEffects.isNotEmpty()) {
            DetailCard(
                title = "Serious Adverse Reactions",
                bgColor = Rose50,
                borderColor = Rose100,
                titleColor = Rose700
            ) {
                medicine.seriousSideEffects.forEach { serious ->
                    BulletPoint(text = serious, color = Rose700)
                }
            }
        }

        // Contraindications
        DetailCard(
            title = "Contraindications & Warnings",
            bgColor = Amber50,
            borderColor = Amber100,
            titleColor = Amber700
        ) {
            medicine.contraindications.forEach { item ->
                BulletPoint(text = "Contraindicated: $item", color = Amber700)
            }
            medicine.warnings.forEach { item ->
                BulletPoint(text = "Warning: $item", color = Slate800)
            }
        }

        // Pregnancy & Special Populations
        DetailCard(title = "Pregnancy & Special Populations") {
            DetailItem(label = "Pregnancy Category / Guidance", value = medicine.specialPopulations.pregnancy)
            if (medicine.specialPopulations.lactation.isNotEmpty()) {
                DetailItem(label = "Lactation", value = medicine.specialPopulations.lactation)
            }
            if (medicine.specialPopulations.pediatric.isNotEmpty()) {
                DetailItem(label = "Pediatric", value = medicine.specialPopulations.pediatric)
            }
        }
    }
}

@Composable
private fun InteractionsAndAdmeTabContent(medicine: MedicineRecord) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Drug Interactions
        DetailCard(title = "Drug Interactions") {
            if (medicine.drugInteractions.isEmpty()) {
                Text("No major interactions listed in dataset.", style = MaterialTheme.typography.bodyMedium, color = Slate500)
            } else {
                medicine.drugInteractions.forEach { inter ->
                    val badgeColor = when (inter.severity) {
                        "Major" -> Rose100
                        "Moderate" -> Amber100
                        else -> Blue100
                    }
                    val textColor = when (inter.severity) {
                        "Major" -> Rose700
                        "Moderate" -> Amber700
                        else -> Blue700
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = inter.medicineName,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Slate900
                            )
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(badgeColor)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = inter.severity,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = textColor
                                )
                            }
                        }
                        Text(text = inter.description, style = MaterialTheme.typography.bodySmall, color = Slate700)
                        Text(text = "Management: ${inter.clinicalConsideration}", style = MaterialTheme.typography.labelSmall, color = Slate500)
                        Divider(modifier = Modifier.padding(top = 6.dp), color = Slate200)
                    }
                }
            }
        }

        // ADME
        DetailCard(
            title = "Pharmacokinetics (ADME)",
            bgColor = Purple50,
            borderColor = Purple100,
            titleColor = Purple700
        ) {
            DetailItem(label = "Absorption", value = medicine.adme.absorption)
            DetailItem(label = "Bioavailability", value = medicine.adme.bioavailability)
            DetailItem(label = "Distribution", value = medicine.adme.distribution)
            DetailItem(label = "Protein Binding", value = medicine.adme.proteinBinding)
            DetailItem(label = "Metabolism", value = medicine.adme.metabolism)
            if (medicine.adme.majorEnzymes.isNotEmpty()) {
                DetailItem(label = "Enzymes", value = medicine.adme.majorEnzymes.joinToString(", "))
            }
            DetailItem(label = "Excretion", value = medicine.adme.excretion)
            DetailItem(label = "Half Life", value = medicine.adme.halfLife)
        }
    }
}

@Composable
private fun DetailCard(
    title: String,
    bgColor: Color = Color.White,
    borderColor: Color = Slate200,
    titleColor: Color = Slate800,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                ),
                color = titleColor
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun DetailItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Slate500)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = Slate800)
    }
}

@Composable
private fun BulletPoint(text: String, color: Color = Slate800) {
    Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
        Text("• ", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = color)
        Text(text = text, style = MaterialTheme.typography.bodyMedium, color = color)
    }
}
