package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MedicineRepository
import com.example.model.MedicineRecord
import com.example.ui.components.MedicineCard
import com.example.ui.components.MedicineDetailSheet
import com.example.ui.screens.*
import com.example.ui.theme.*

@Composable
fun MainScreen(
    viewModel: MainViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val activeCategory by viewModel.activeCategory.collectAsStateWithLifecycle()
    val selectedTherapeuticFilter by viewModel.selectedTherapeuticFilter.collectAsStateWithLifecycle()
    val selectedMedicine by viewModel.selectedMedicine.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val recentlyViewedIds by viewModel.recentlyViewedIds.collectAsStateWithLifecycle()
    val interactionSelectedIds by viewModel.interactionSelectedIds.collectAsStateWithLifecycle()
    val explanationMode by viewModel.explanationMode.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

    val allMeds = remember { MedicineRepository.allMedicines }

    val filteredMedicines = remember(searchQuery, selectedTherapeuticFilter, activeCategory) {
        var result = MedicineRepository.search(searchQuery)
        if (selectedTherapeuticFilter != "All") {
            result = result.filter { it.therapeuticClass.contains(selectedTherapeuticFilter, ignoreCase = true) }
        }
        result
    }

    val recentlyViewedMeds = remember(recentlyViewedIds) {
        recentlyViewedIds.mapNotNull { id -> allMeds.find { it.id == id } }
    }

    val favoriteMeds = remember(favoriteIds) {
        allMeds.filter { favoriteIds.contains(it.id) }
    }

    MyApplicationTheme(darkTheme = isDarkTheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBarContent(
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { viewModel.toggleDarkTheme() }
                )
            },
            bottomBar = {
                BottomNavBarContent(
                    selectedTab = selectedTab,
                    onTabSelect = { tab ->
                        viewModel.selectTab(tab)
                        viewModel.selectCategory(ActiveCategory.ALL)
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Global Search Bar
                    SearchBarContent(
                        query = searchQuery,
                        onQueryChange = { viewModel.updateSearchQuery(it) }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Therapeutic Filter Chips
                    TherapeuticFilterRow(
                        selectedFilter = selectedTherapeuticFilter,
                        onFilterSelect = { viewModel.setTherapeuticFilter(it) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dynamic Main Tab / Category View
                    when {
                        // Category sub-screens override
                        activeCategory == ActiveCategory.BRAND2GEN -> {
                            BrandToGenericScreen(
                                onMedicineClick = { viewModel.openMedicineDetail(it) }
                            )
                        }
                        activeCategory == ActiveCategory.INTERACTIONS -> {
                            InteractionCheckerScreen(
                                selectedMedicineIds = interactionSelectedIds,
                                onToggleMedicine = { viewModel.toggleInteractionMedicine(it) }
                            )
                        }
                        activeCategory == ActiveCategory.ADME -> {
                            AdmeExplorerScreen(
                                onMedicineClick = { viewModel.openMedicineDetail(it) }
                            )
                        }
                        activeCategory == ActiveCategory.MEMORY -> {
                            SuffixMemoryScreen()
                        }
                        activeCategory == ActiveCategory.TERMS -> {
                            MedicalLexiconScreen(
                                selectedMode = explanationMode,
                                onModeSelect = { viewModel.setExplanationMode(it) }
                            )
                        }
                        activeCategory == ActiveCategory.AI_ASK -> {
                            AiAskScreen()
                        }

                        // Core Tab Views
                        selectedTab == NavigationTab.HOME -> {
                            HomeScreen(
                                medicines = filteredMedicines,
                                recentlyViewedMeds = recentlyViewedMeds,
                                favoriteIds = favoriteIds,
                                activeCategory = activeCategory,
                                onCategorySelect = { viewModel.selectCategory(it) },
                                onMedicineClick = { viewModel.openMedicineDetail(it) },
                                onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                onViewAllClick = { viewModel.selectTab(NavigationTab.MEDS) }
                            )
                        }
                        selectedTab == NavigationTab.MEDS -> {
                            MedicinesListScreen(
                                medicines = filteredMedicines,
                                favoriteIds = favoriteIds,
                                onMedicineClick = { viewModel.openMedicineDetail(it) },
                                onFavoriteToggle = { viewModel.toggleFavorite(it) }
                            )
                        }
                        selectedTab == NavigationTab.LEARN -> {
                            SuffixMemoryScreen()
                        }
                        selectedTab == NavigationTab.FAVS -> {
                            FavoritesScreen(
                                favoriteMedicines = favoriteMeds,
                                favoriteIds = favoriteIds,
                                onMedicineClick = { viewModel.openMedicineDetail(it) },
                                onFavoriteToggle = { viewModel.toggleFavorite(it) }
                            )
                        }
                    }
                }

                // Detail Modal Sheet
                selectedMedicine?.let { medicine ->
                    MedicineDetailSheet(
                        medicine = medicine,
                        isFavorite = favoriteIds.contains(medicine.id),
                        onFavoriteToggle = { viewModel.toggleFavorite(medicine.id) },
                        onDismiss = { viewModel.closeMedicineDetail() }
                    )
                }
            }
        }
    }
}

@Composable
private fun TopAppBarContent(
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, Slate200, RoundedCornerShape(24.dp)),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // MediVault.in Brand Logo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Emerald600),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.HealthAndSafety,
                        contentDescription = "MediVault Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Row {
                    Text(
                        text = "MediVault",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = ".in",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        ),
                        color = Emerald600
                    )
                }
            }

            // Dark Mode Toggle
            IconButton(
                onClick = onToggleDarkTheme,
                modifier = Modifier.testTag("theme_toggle_button")
            ) {
                Icon(
                    imageVector = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                    contentDescription = "Toggle Theme",
                    tint = Slate600
                )
            }
        }
    }
}

@Composable
private fun SearchBarContent(
    query: String,
    onQueryChange: (String) -> Unit
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = {
            Text(
                text = "Search medicine, brand, salt or class...",
                style = MaterialTheme.typography.bodyMedium,
                color = Slate400
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Outlined.Search,
                contentDescription = "Search",
                tint = Slate500
            )
        },
        trailingIcon = if (query.isNotEmpty()) {
            {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Clear",
                        tint = Slate500
                    )
                }
            }
        } else null,
        singleLine = true,
        shape = RoundedCornerShape(24.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedBorderColor = Emerald600,
            unfocusedBorderColor = Slate200
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("global_search_bar")
    )
}

@Composable
private fun TherapeuticFilterRow(
    selectedFilter: String,
    onFilterSelect: (String) -> Unit
) {
    val filters = listOf(
        "All", "Antibiotic", "Analgesic", "Antidiabetic", "Gastroprotective",
        "Antihistamine", "Antiemetic", "Antihypertensive", "Cardiovascular"
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(filters) { filter ->
            val isSelected = filter == selectedFilter
            FilterChip(
                selected = isSelected,
                onClick = { onFilterSelect(filter) },
                label = {
                    Text(
                        text = filter,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Emerald100,
                    selectedLabelColor = Emerald700,
                    containerColor = MaterialTheme.colorScheme.surface,
                    labelColor = Slate700
                ),
                shape = RoundedCornerShape(16.dp),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = if (isSelected) Emerald600 else Slate200
                ),
                modifier = Modifier.testTag("filter_chip_$filter")
            )
        }
    }
}

@Composable
private fun MedicinesListScreen(
    medicines: List<MedicineRecord>,
    favoriteIds: Set<String>,
    onMedicineClick: (MedicineRecord) -> Unit,
    onFavoriteToggle: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("medicines_full_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "FULL MEDICINE DATABASE (${medicines.size} Records)",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                ),
                color = Slate800
            )
        }

        items(medicines, key = { it.id }) { med ->
            MedicineCard(
                medicine = med,
                isFavorite = favoriteIds.contains(med.id),
                onCardClick = { onMedicineClick(med) },
                onFavoriteToggle = { onFavoriteToggle(med.id) }
            )
        }
    }
}

@Composable
private fun FavoritesScreen(
    favoriteMedicines: List<MedicineRecord>,
    favoriteIds: Set<String>,
    onMedicineClick: (MedicineRecord) -> Unit,
    onFavoriteToggle: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("favorites_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "BOOKMARKED MEDICINES (${favoriteMedicines.size})",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                ),
                color = Slate800
            )
        }

        if (favoriteMedicines.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No saved medicines yet. Tap heart icons on cards to bookmark.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate500
                    )
                }
            }
        } else {
            items(favoriteMedicines, key = { it.id }) { med ->
                MedicineCard(
                    medicine = med,
                    isFavorite = true,
                    onCardClick = { onMedicineClick(med) },
                    onFavoriteToggle = { onFavoriteToggle(med.id) }
                )
            }
        }
    }
}

@Composable
private fun BottomNavBarContent(
    selectedTab: NavigationTab,
    onTabSelect: (NavigationTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_nav_bar")
    ) {
        NavigationBarItem(
            selected = selectedTab == NavigationTab.HOME,
            onClick = { onTabSelect(NavigationTab.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Emerald700,
                selectedTextColor = Emerald700,
                indicatorColor = Emerald100
            ),
            modifier = Modifier.testTag("nav_tab_home")
        )

        NavigationBarItem(
            selected = selectedTab == NavigationTab.MEDS,
            onClick = { onTabSelect(NavigationTab.MEDS) },
            icon = { Icon(Icons.Default.Medication, contentDescription = "Meds") },
            label = { Text("Meds", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Emerald700,
                selectedTextColor = Emerald700,
                indicatorColor = Emerald100
            ),
            modifier = Modifier.testTag("nav_tab_meds")
        )

        NavigationBarItem(
            selected = selectedTab == NavigationTab.LEARN,
            onClick = { onTabSelect(NavigationTab.LEARN) },
            icon = { Icon(Icons.Default.School, contentDescription = "Learn") },
            label = { Text("Learn", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Emerald700,
                selectedTextColor = Emerald700,
                indicatorColor = Emerald100
            ),
            modifier = Modifier.testTag("nav_tab_learn")
        )

        NavigationBarItem(
            selected = selectedTab == NavigationTab.FAVS,
            onClick = { onTabSelect(NavigationTab.FAVS) },
            icon = { Icon(Icons.Default.Favorite, contentDescription = "Favs") },
            label = { Text("Favs", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Emerald700,
                selectedTextColor = Emerald700,
                indicatorColor = Emerald100
            ),
            modifier = Modifier.testTag("nav_tab_favs")
        )
    }
}
