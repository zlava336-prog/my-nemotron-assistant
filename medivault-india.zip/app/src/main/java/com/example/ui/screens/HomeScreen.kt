package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MedicineRecord
import com.example.ui.ActiveCategory
import com.example.ui.components.MedicineCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    medicines: List<MedicineRecord>,
    recentlyViewedMeds: List<MedicineRecord>,
    favoriteIds: Set<String>,
    activeCategory: ActiveCategory,
    onCategorySelect: (ActiveCategory) -> Unit,
    onMedicineClick: (MedicineRecord) -> Unit,
    onFavoriteToggle: (String) -> Unit,
    onViewAllClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Actions Grid (8 Items as per Immersive UI theme)
        item {
            QuickActionsGrid(
                activeCategory = activeCategory,
                onCategorySelect = onCategorySelect
            )
        }

        // Section Title: Recently Viewed / Featured
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (activeCategory == ActiveCategory.ALL) "RECENTLY VIEWED" else "FEATURED MEDICINES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 1.2.sp
                    ),
                    color = Slate800
                )

                TextButton(
                    onClick = onViewAllClick,
                    modifier = Modifier.testTag("view_all_button")
                ) {
                    Text(
                        text = "VIEW ALL",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        color = Emerald600
                    )
                }
            }
        }

        // Recently Viewed / Top Medicines List
        val displayList = if (recentlyViewedMeds.isNotEmpty() && activeCategory == ActiveCategory.ALL) {
            recentlyViewedMeds
        } else {
            medicines.take(6)
        }

        items(displayList, key = { it.id }) { medicine ->
            MedicineCard(
                medicine = medicine,
                isFavorite = favoriteIds.contains(medicine.id),
                onCardClick = { onMedicineClick(medicine) },
                onFavoriteToggle = { onFavoriteToggle(medicine.id) }
            )
        }

        // Educational Disclaimer Banner (Immersive UI Style)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Slate800)
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "EDUCATIONAL REFERENCE ONLY",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        ),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "This app does not replace advice, diagnosis, or treatment from a qualified healthcare professional. Never self-prescribe.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        ),
                        color = Slate300
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionsGrid(
    activeCategory: ActiveCategory,
    onCategorySelect: (ActiveCategory) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Row 1
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickActionTile(
                title = "Medicines",
                icon = Icons.Outlined.Medication,
                bgColor = Emerald50,
                iconColor = Emerald700,
                isSelected = activeCategory == ActiveCategory.MEDICINES,
                onClick = { onCategorySelect(ActiveCategory.MEDICINES) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "Brand 2 Gen",
                icon = Icons.Outlined.SwapHoriz,
                bgColor = Blue50,
                iconColor = Blue700,
                isSelected = activeCategory == ActiveCategory.BRAND2GEN,
                onClick = { onCategorySelect(ActiveCategory.BRAND2GEN) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "Classes",
                icon = Icons.Outlined.Layers,
                bgColor = Amber50,
                iconColor = Amber700,
                isSelected = activeCategory == ActiveCategory.CLASSES,
                onClick = { onCategorySelect(ActiveCategory.CLASSES) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "Interactions",
                icon = Icons.Outlined.Warning,
                bgColor = Rose50,
                iconColor = Rose700,
                isSelected = activeCategory == ActiveCategory.INTERACTIONS,
                onClick = { onCategorySelect(ActiveCategory.INTERACTIONS) },
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickActionTile(
                title = "ADME",
                icon = Icons.Outlined.Biotech,
                bgColor = Purple50,
                iconColor = Purple700,
                isSelected = activeCategory == ActiveCategory.ADME,
                onClick = { onCategorySelect(ActiveCategory.ADME) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "Memory",
                icon = Icons.Outlined.Psychology,
                bgColor = Cyan50,
                iconColor = Cyan700,
                isSelected = activeCategory == ActiveCategory.MEMORY,
                onClick = { onCategorySelect(ActiveCategory.MEMORY) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "Terms",
                icon = Icons.Outlined.Book,
                bgColor = Indigo50,
                iconColor = Indigo700,
                isSelected = activeCategory == ActiveCategory.TERMS,
                onClick = { onCategorySelect(ActiveCategory.TERMS) },
                modifier = Modifier.weight(1f)
            )
            QuickActionTile(
                title = "AI Ask",
                icon = Icons.Outlined.AutoAwesome,
                bgColor = Slate900,
                iconColor = Color.White,
                isSelected = activeCategory == ActiveCategory.AI_ASK,
                onClick = { onCategorySelect(ActiveCategory.AI_ASK) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun QuickActionTile(
    title: String,
    icon: ImageVector,
    bgColor: Color,
    iconColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .padding(horizontal = 2.dp)
            .clickable(onClick = onClick)
            .testTag("quick_action_${title.lowercase().replace(" ", "_")}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(if (isSelected) iconColor else bgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) Color.White else iconColor,
                modifier = Modifier.size(26.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                letterSpacing = 0.2.sp
            ),
            color = Slate600,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
