package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRepository
import com.example.model.MedicineRecord
import com.example.ui.theme.*

@Composable
fun InteractionCheckerScreen(
    selectedMedicineIds: Set<String>,
    onToggleMedicine: (String) -> Unit
) {
    val allMeds = remember { MedicineRepository.allMedicines }
    val interactions = remember(selectedMedicineIds) {
        MedicineRepository.findInteractions(selectedMedicineIds.toList())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("interaction_checker_screen")
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Rose50)
                .border(1.dp, Rose100, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Warning, contentDescription = null, tint = Rose700, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DRUG INTERACTION CHECKER",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = Rose700
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Select 2 or more medicines to evaluate potential drug-drug interaction risks.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Multi-select Medicine Chips
        Text(
            text = "SELECT MEDICINES TO EVALUATE (${selectedMedicineIds.size} Selected):",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Slate600
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(allMeds) { med ->
                val isSelected = selectedMedicineIds.contains(med.id)
                FilterChip(
                    selected = isSelected,
                    onClick = { onToggleMedicine(med.id) },
                    label = { Text(med.genericName) },
                    leadingIcon = if (isSelected) {
                        { Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Rose100,
                        selectedLabelColor = Rose700,
                        containerColor = Color.White,
                        labelColor = Slate700
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("interaction_chip_${med.genericName}")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interaction Results List
        if (selectedMedicineIds.size < 2) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Please select at least 2 medicines above to view interaction analysis.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate500
                )
            }
        } else if (interactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Emerald50)
                    .border(1.dp, Emerald100, RoundedCornerShape(20.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = Emerald700, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "No direct major interaction warnings found in dataset between the selected drugs.",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Emerald700
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(interactions) { item ->
                    val (med1, med2, inter) = item
                    val badgeColor = when (inter.severity) {
                        "Major" -> Rose100
                        "Moderate" -> Amber100
                        else -> Blue100
                    }
                    val textColor = when (inter.severity) {
                        "Major" -> Rose700
                        "Moderate" -> Amber700
                        else -> Blue700
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White)
                            .border(1.dp, Slate200, RoundedCornerShape(20.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${med1.genericName} + ${med2.genericName}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                    color = Slate900
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(badgeColor)
                                        .padding(horizontal = 10.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${inter.severity} Risk",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = textColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = inter.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Slate800
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Mechanism: ${inter.mechanism}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate600
                            )

                            Text(
                                text = "Clinical Consideration: ${inter.clinicalConsideration}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Rose700
                            )
                        }
                    }
                }
            }
        }
    }
}
