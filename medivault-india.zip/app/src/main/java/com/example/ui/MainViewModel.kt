package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MedicineRepository
import com.example.model.ExplanationMode
import com.example.model.MedicineRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class NavigationTab {
    HOME,
    MEDS,
    LEARN,
    FAVS
}

enum class ActiveCategory {
    ALL,
    MEDICINES,
    BRAND2GEN,
    CLASSES,
    INTERACTIONS,
    ADME,
    MEMORY,
    TERMS,
    AI_ASK
}

class MainViewModel : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(NavigationTab.HOME)
    val selectedTab: StateFlow<NavigationTab> = _selectedTab.asStateFlow()

    private val _activeCategory = MutableStateFlow(ActiveCategory.ALL)
    val activeCategory: StateFlow<ActiveCategory> = _activeCategory.asStateFlow()

    private val _selectedTherapeuticFilter = MutableStateFlow("All")
    val selectedTherapeuticFilter: StateFlow<String> = _selectedTherapeuticFilter.asStateFlow()

    private val _selectedMedicine = MutableStateFlow<MedicineRecord?>(null)
    val selectedMedicine: StateFlow<MedicineRecord?> = _selectedMedicine.asStateFlow()

    private val _favoriteIds = MutableStateFlow<Set<String>>(setOf("med-001", "med-005", "med-027"))
    val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

    private val _recentlyViewedIds = MutableStateFlow<List<String>>(listOf("med-001", "med-005", "med-027", "med-030"))
    val recentlyViewedIds: StateFlow<List<String>> = _recentlyViewedIds.asStateFlow()

    private val _interactionSelectedIds = MutableStateFlow<Set<String>>(setOf("med-001", "med-035"))
    val interactionSelectedIds: StateFlow<Set<String>> = _interactionSelectedIds.asStateFlow()

    private val _explanationMode = MutableStateFlow(ExplanationMode.HINGLISH)
    val explanationMode: StateFlow<ExplanationMode> = _explanationMode.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectTab(tab: NavigationTab) {
        _selectedTab.value = tab
    }

    fun selectCategory(category: ActiveCategory) {
        _activeCategory.value = category
        when (category) {
            ActiveCategory.BRAND2GEN -> _selectedTab.value = NavigationTab.MEDS
            ActiveCategory.MEMORY -> _selectedTab.value = NavigationTab.LEARN
            ActiveCategory.TERMS -> _selectedTab.value = NavigationTab.LEARN
            ActiveCategory.INTERACTIONS -> _selectedTab.value = NavigationTab.LEARN
            ActiveCategory.ADME -> _selectedTab.value = NavigationTab.LEARN
            ActiveCategory.AI_ASK -> _selectedTab.value = NavigationTab.LEARN
            else -> {}
        }
    }

    fun setTherapeuticFilter(filter: String) {
        _selectedTherapeuticFilter.value = filter
    }

    fun openMedicineDetail(medicine: MedicineRecord) {
        _selectedMedicine.value = medicine
        val currentRecent = _recentlyViewedIds.value.toMutableList()
        currentRecent.remove(medicine.id)
        currentRecent.add(0, medicine.id)
        _recentlyViewedIds.value = currentRecent.take(10)
    }

    fun closeMedicineDetail() {
        _selectedMedicine.value = null
    }

    fun toggleFavorite(medicineId: String) {
        val currentFavs = _favoriteIds.value.toMutableSet()
        if (currentFavs.contains(medicineId)) {
            currentFavs.remove(medicineId)
        } else {
            currentFavs.add(medicineId)
        }
        _favoriteIds.value = currentFavs
    }

    fun toggleInteractionMedicine(medicineId: String) {
        val current = _interactionSelectedIds.value.toMutableSet()
        if (current.contains(medicineId)) {
            current.remove(medicineId)
        } else {
            current.add(medicineId)
        }
        _interactionSelectedIds.value = current
    }

    fun setExplanationMode(mode: ExplanationMode) {
        _explanationMode.value = mode
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }
}
