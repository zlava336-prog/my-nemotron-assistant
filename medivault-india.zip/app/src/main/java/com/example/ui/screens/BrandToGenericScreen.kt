package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineRepository
import com.example.model.BrandInfo
import com.example.model.MedicineRecord
import com.example.ui.theme.*

@Composable
fun BrandToGenericScreen(
    onMedicineClick: (MedicineRecord) -> Unit
) {
    var brandQuery by remember { mutableStateOf("") }
    val allBrands = remember { MedicineRepository.getAllBrands() }

    val filteredBrands = remember(brandQuery) {
        if (brandQuery.trim().isEmpty()) {
            allBrands
        } else {
            val q = brandQuery.trim().lowercase()
            allBrands.filter { (brand, med) ->
                brand.brandName.lowercase().contains(q) ||
                brand.manufacturer.lowercase().contains(q) ||
                med.genericName.lowercase().contains(q) ||
                med.saltName.lowercase().contains(q)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("brand_to_generic_screen")
    ) {
        // Search Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Blue50)
                .border(1.dp, Blue100, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.SwapHoriz,
                        contentDescription = null,
                        tint = Blue700,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INDIAN BRAND TO GENERIC FINDER",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = Blue700
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Find active generic salt compositions & price for popular Indian medicine brand names.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = brandQuery,
                    onValueChange = { brandQuery = it },
                    placeholder = { Text("Search brand e.g. Crocin, Dolo, Augmentin, Pan 40...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = Blue700) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Blue700,
                        unfocusedBorderColor = Slate200
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("brand_search_input")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Results List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredBrands) { (brand, med) ->
                BrandCardItem(
                    brand = brand,
                    medicine = med,
                    onClick = { onMedicineClick(med) }
                )
            }
        }
    }
}

@Composable
private fun BrandCardItem(
    brand: BrandInfo,
    medicine: MedicineRecord,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White)
            .border(1.dp, Slate200, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
            .testTag("brand_item_${brand.brandName}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = brand.brandName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    ),
                    color = Slate900
                )

                if (brand.estimatedPrice.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Emerald100)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = brand.estimatedPrice,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Emerald700
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Generic Salt: ${medicine.genericName} (${medicine.saltName})",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Blue700
            )

            Text(
                text = "Manufacturer: ${brand.manufacturer} • Dose: ${brand.strength}",
                style = MaterialTheme.typography.bodySmall,
                color = Slate600
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Therapeutic Class: ${medicine.therapeuticClass}",
                style = MaterialTheme.typography.labelSmall,
                color = Slate500
            )
        }
    }
}
