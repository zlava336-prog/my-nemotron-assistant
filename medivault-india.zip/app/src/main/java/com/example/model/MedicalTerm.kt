package com.example.model

enum class ExplanationMode {
    SIMPLE,
    HINGLISH,
    STUDENT,
    MEDICAL
}

data class TermExplanations(
    val simple: String,
    val hinglish: String,
    val student: String,
    val medical: String
)

data class MedicalTerm(
    val id: String,
    val term: String,
    val category: String,
    val phonetic: String,
    val explanations: TermExplanations,
    val relatedMedicines: List<String> = emptyList()
)
