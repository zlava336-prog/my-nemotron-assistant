package com.example.model

data class SuffixPattern(
    val id: String,
    val pattern: String,
    val drugClass: String,
    val therapeuticCategory: String,
    val description: String,
    val memoryTrick: String,
    val examples: List<String>,
    val exceptions: String = "Pattern is a memory aid, not an absolute rule."
)
