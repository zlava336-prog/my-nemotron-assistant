package com.example.model

data class BrandInfo(
    val brandName: String,
    val genericName: String = "",
    val activeIngredients: List<String> = emptyList(),
    val strength: String,
    val dosageForm: String,
    val manufacturer: String,
    val isCombination: Boolean = false,
    val estimatedPrice: String = ""
)

data class ADMEInfo(
    val absorption: String,
    val distribution: String,
    val metabolism: String,
    val excretion: String,
    val bioavailability: String = "Not available in current dataset.",
    val proteinBinding: String = "Not available in current dataset.",
    val volumeOfDistribution: String = "Not available in current dataset.",
    val metabolicPathway: String = "Not available in current dataset.",
    val majorEnzymes: List<String> = emptyList(),
    val halfLife: String = "Not available in current dataset.",
    val routeOfElimination: String = "Not available in current dataset."
)

data class StructuredInteraction(
    val medicineName: String,
    val severity: String, // Major, Moderate, Minor
    val description: String,
    val mechanism: String,
    val clinicalConsideration: String
)

data class SpecialPopulations(
    val pregnancy: String = "Use under medical supervision.",
    val lactation: String = "Consult physician before use.",
    val pediatric: String = "Dose adjustment required based on age/weight.",
    val geriatric: String = "Monitor renal/hepatic parameters closely.",
    val renal: String = "Dose adjustment or caution required in renal impairment.",
    val hepatic: String = "Caution in severe hepatic impairment."
)

data class MedicineRecord(
    val id: String,
    val genericName: String,
    val saltName: String,
    val activeIngredients: List<String>,
    val brandNames: List<BrandInfo>,
    val strength: String,
    val dosageForms: List<String>,
    val routes: List<String>,
    val pronunciation: String,
    val romanPronunciation: String,
    val hinglishPronunciation: String,
    val therapeuticClass: String,
    val pharmacologicalClass: String,
    val drugClass: String,
    val atcCode: String = "",
    val mechanismOfAction: String,
    val indications: List<String>,
    val uses: List<String>,
    val contraindications: List<String>,
    val warnings: List<String>,
    val precautions: List<String>,
    val adverseEffects: List<String>,
    val commonSideEffects: List<String> = emptyList(),
    val seriousSideEffects: List<String> = emptyList(),
    val drugInteractions: List<StructuredInteraction> = emptyList(),
    val foodInteractions: List<String> = emptyList(),
    val adme: ADMEInfo,
    val specialPopulations: SpecialPopulations = SpecialPopulations(),
    val monitoring: List<String> = emptyList(),
    val patientCounselling: List<String> = emptyList(),
    val advantages: List<String> = emptyList(),
    val limitations: List<String> = emptyList(),
    val memoryTrick: String = "",
    val references: List<String> = emptyList(),
    val sourceUrls: List<String> = emptyList(),
    val lastVerifiedDate: String = "2026-08-12",
    val dataVersion: String = "1.0",
    val medicalReviewStatus: String = "Demonstration Data"
)
